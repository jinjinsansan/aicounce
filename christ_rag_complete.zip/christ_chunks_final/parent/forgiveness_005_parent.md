---
id: forgiveness_005_parent
type: parent
book: ルカによる福音書
chapter: 23
verses: "34"
speaker: キリスト
theme: ['赦し', '十字架', '無知']
situation: ['究極の赦し', '敵を赦す', 'キリストの模範']
token_estimate: 27
---

# ルカによる福音書 23章34節

そのとき、イエスは言われた、「父よ、彼らをおゆるしください。彼らは何をしているのか、わからずにいるのです」。