---
id: wisdom_002_parent
type: parent
book: ヤコブの手紙
chapter: 1
verses: "5"
speaker: ヤコブ
theme: ['知恵', '祈り', '神の寛大さ']
situation: ['知恵が必要', '判断に迷う', '神に求める']
token_estimate: 37
---

# ヤコブの手紙 1章5節

あなたがたのうち、知恵に乏しい者があれば、その人は、とがめもせずに惜しみなくすべての人に与える神に、願い求めるがよい。そうすれば、与えられるであろう。