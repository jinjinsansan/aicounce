---
id: peace_004_parent
type: parent
book: 詩篇
chapter: 4
verses: "8"
speaker: ダビデ
theme: ['平安', '安眠', '安全']
situation: ['眠れない', '安心したい', '守られたい']
token_estimate: 24
---

# 詩篇 4章8節

わたしは安らかに横になり、眠りにつきます。主よ、あなただけが安全にわたしを住まわせてくださいます。