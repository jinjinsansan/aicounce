---
id: faith_012_parent
type: parent
book: ローマ人への手紙
chapter: 10
verses: "17"
speaker: パウロ
theme: ['信仰', '聞くこと', '御言葉']
situation: ['信仰を強めたい', '御言葉の大切さ', '信仰の起源']
token_estimate: 21
---

# ローマ人への手紙 10章17節

したがって、信仰は聞くことによるのであり、聞くことはキリストの言葉から来るのである。