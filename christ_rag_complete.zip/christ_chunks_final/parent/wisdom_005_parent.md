---
id: wisdom_005_parent
type: parent
book: 箴言
chapter: 4
verses: "7"
speaker: ソロモン
theme: ['知恵', '悟り', '獲得']
situation: ['知恵の価値', '何を求めるべきか', '優先順位']
token_estimate: 18
---

# 箴言 4章7節

知恵の初めはこれである、知恵を得よ、あなたが何を得るにしても、悟りを得よ。