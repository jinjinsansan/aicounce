---
id: strength_002_parent
type: parent
book: イザヤ書
chapter: 41
verses: "10"
speaker: 神
theme: ['恐れ', '強さ', '助け']
situation: ['恐れている', '助けが必要', '一人で不安']
token_estimate: 42
---

# イザヤ書 41章10節

恐れてはならない、わたしはあなたと共にいる。驚いてはならない、わたしはあなたの神である。わたしはあなたを強くし、あなたを助け、わが勝利の右の手をもって、あなたをささえる。