---
id: guidance_003_parent
type: parent
book: イザヤ書
chapter: 30
verses: "21"
speaker: 神
theme: ['導き', '神の声', '方向']
situation: ['神の声が聞こえない', 'どちらに進むべきかわからない']
token_estimate: 28
---

# イザヤ書 30章21節

また、あなたが右に行き、あるいは左に行く時、あなたの耳は、うしろから「これは道だ、これに歩め」と言う言葉を聞く。