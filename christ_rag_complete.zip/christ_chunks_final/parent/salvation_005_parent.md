---
id: salvation_005_parent
type: parent
book: ヨハネによる福音書
chapter: 14
verses: "6"
speaker: キリスト
theme: ['道', '真理', '命']
situation: ['神に近づく道', '真理とは', '永遠の命']
token_estimate: 31
---

# ヨハネによる福音書 14章6節

イエスは彼に言われた、「わたしは道であり、真理であり、命である。だれでもわたしによらないでは、父のみもとに行くことはできない。