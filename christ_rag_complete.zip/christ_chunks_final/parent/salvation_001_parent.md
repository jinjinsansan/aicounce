---
id: salvation_001_parent
type: parent
book: ローマ人への手紙
chapter: 3
verses: "23-24"
speaker: パウロ
theme: ['罪', '恵み', '義']
situation: ['罪の自覚', '救いの必要', '恵みを理解']
token_estimate: 41
---

# ローマ人への手紙 3章23-24節

すなわち、すべての人は罪を犯したため、神の栄光を受けられなくなっており、彼らは、価なしに、神の恵みにより、キリスト・イエスによるあがないによって義とされるのである。