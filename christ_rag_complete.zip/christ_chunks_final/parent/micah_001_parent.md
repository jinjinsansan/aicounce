---
id: micah_001_parent
type: parent
book: ミカ書
chapter: 6
verses: "8"
speaker: ミカ
theme: ['正義', '愛', '謙遜', '神が求めるもの']
situation: ['神が何を求めているかわからない', '信仰の本質を知りたい']
token_estimate: 33
---

# ミカ書 6章8節

人よ、何が善いことであるか、主はあなたに告げられた。ただ正義を行い、いつくしみを愛し、へりくだってあなたの神と共に歩むことではないか。