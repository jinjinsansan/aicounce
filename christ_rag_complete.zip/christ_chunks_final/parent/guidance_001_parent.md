---
id: guidance_001_parent
type: parent
book: 詩篇
chapter: 32
verses: "8"
speaker: 神
theme: ['導き', '神の教え', '人生の方向']
situation: ['どうすればいいかわからない', '人生の岐路にいる', '進むべき道が見えない']
token_estimate: 23
---

# 詩篇 32章8節

わたしはあなたを教え、あなたの行くべき道を示し、わたしの目をあなたにとめて、さとすであろう。