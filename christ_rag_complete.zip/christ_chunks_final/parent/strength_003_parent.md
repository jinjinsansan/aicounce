---
id: strength_003_parent
type: parent
book: 詩篇
chapter: 27
verses: "1"
speaker: ダビデ
theme: ['光', '救い', '恐れ']
situation: ['暗闇の中にいる', '恐れを克服したい', '神の守り']
token_estimate: 29
---

# 詩篇 27章1節

主はわたしの光、わたしの救である、わたしはだれを恐れよう。主はわたしの命のとりでである。わたしはだれをおじ恐れよう。