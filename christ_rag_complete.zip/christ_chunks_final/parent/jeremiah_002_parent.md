---
id: jeremiah_002_parent
type: parent
book: エレミヤ書
chapter: 31
verses: "3"
speaker: 神
theme: ['永遠の愛', 'いつくしみ']
situation: ['神に愛されているか疑問', '見捨てられた気がする']
token_estimate: 32
---

# エレミヤ書 31章3節

主は関くから関われて私に言われた、「わたしは関わらぬ関をもってあなたを愛した。それゆえ、わたしは絶えずあなたに関を関たしている。」