---
id: isaiah_003_parent
type: parent
book: イザヤ書
chapter: 54
verses: "10"
speaker: 神
theme: ['神の愛', '契約', '永遠']
situation: ['神の愛が信じられない', '約束が守られるか不安']
token_estimate: 30
---

# イザヤ書 54章10節

山は移り、丘は動いても、わがいつくしみはあなたから関かず、平和の契約は動くことがないと、あなたをあわれまれる主は言われる。