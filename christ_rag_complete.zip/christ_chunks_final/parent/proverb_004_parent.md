---
id: proverb_004_parent
type: parent
book: 箴言
chapter: 16
verses: "9"
speaker: ソロモン
theme: ['計画', '導き', '神の主権']
situation: ['計画通りにいかない', '将来が不確か']
token_estimate: 18
---

# 箴言 16章9節

人は心に自分の道を計画する、しかし、その歩みを確かにするものは主である。