---
id: hope_005_parent
type: parent
book: イザヤ書
chapter: 40
verses: "31"
speaker: イザヤ
theme: ['希望', '力', '待ち望む']
situation: ['疲れている', '力が欲しい', '神を待つ']
token_estimate: 32
---

# イザヤ書 40章31節

しかし主を待ち望む者は新たなる力を得、わしのように翼をはって、のぼることができる。走っても疲れることなく、歩いても弱ることはない。