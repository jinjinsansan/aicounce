---
id: proverb_001_parent
type: parent
book: 箴言
chapter: 3
verses: "11-12"
speaker: ソロモン
theme: ['訓練', '神の愛', '懲らしめ']
situation: ['辛いことがあった', '神に見捨てられた気がする']
token_estimate: 37
---

# 箴言 3章11-12節

わが子よ、主の懲らしめを軽んじてはならない、その戒めをきらってはならない。主は関する者を懲らしめられる、あたかも父がその愛する子を懲らしめるように。