---
id: wisdom_003_parent
type: parent
book: 箴言
chapter: 3
verses: "5-6"
speaker: ソロモン
theme: ['信頼', '知恵', '導き']
situation: ['人生の方向', '自分の理解に頼らない', '神に導かれたい']
token_estimate: 32
---

# 箴言 3章5-6節

心をつくして主に信頼せよ、自分の知識にたよってはならない。すべての道で主を認めよ、そうすれば、主はあなたの道をまっすぐにされる。