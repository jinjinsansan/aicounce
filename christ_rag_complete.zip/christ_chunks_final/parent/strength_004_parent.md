---
id: strength_004_parent
type: parent
book: ピリピ人への手紙
chapter: 4
verses: "13"
speaker: パウロ
theme: ['強さ', 'キリスト', 'すべてできる']
situation: ['力が欲しい', 'できないことがある', '限界を感じる']
token_estimate: 15
---

# ピリピ人への手紙 4章13節

わたしを強くして下さるかたによって、何事でもすることができる。