---
id: wisdom_001_parent
type: parent
book: 箴言
chapter: 9
verses: "10"
speaker: ソロモン
theme: ['知恵', '畏れ', '知識']
situation: ['知恵を求める', '神を畏れる', '知識の始まり']
token_estimate: 16
---

# 箴言 9章10節

主を恐れることは知恵の本である、聖なる者を知ることは悟りである。