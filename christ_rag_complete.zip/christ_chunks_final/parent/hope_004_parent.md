---
id: hope_004_parent
type: parent
book: 詩篇
chapter: 42
verses: "5"
speaker: 詩篇の作者
theme: ['希望', '励まし', '落胆']
situation: ['落ち込んでいる', '自分を励ましたい', '神を待ち望む']
token_estimate: 35
---

# 詩篇 42章5節

わが魂よ、何ゆえうなだれるのか。何ゆえわたしのうちに思いみだれるのか。神を待ち望め。わたしはなおわが助け、わが神なる主をほめたたえるであろう。