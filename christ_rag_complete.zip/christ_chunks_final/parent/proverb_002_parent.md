---
id: proverb_002_parent
type: parent
book: 箴言
chapter: 4
verses: "23"
speaker: ソロモン
theme: ['心', '守る', 'いのち']
situation: ['心が乱れている', '何を優先すべきかわからない']
token_estimate: 18
---

# 箴言 4章23節

油断することなく、あなたの心を守れ、命の泉は、これからわき出るからである。