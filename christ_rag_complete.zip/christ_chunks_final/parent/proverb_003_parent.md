---
id: proverb_003_parent
type: parent
book: 箴言
chapter: 16
verses: "3"
speaker: ソロモン
theme: ['委ねる', '計画', '成功']
situation: ['計画がうまくいかない', '何かを始めようとしている']
token_estimate: 21
---

# 箴言 16章3節

あなたのなすべき事を主にゆだねよ、そうすれば、あなたの計るところは関ち行くであろう。