---
id: peace_003_parent
type: parent
book: イザヤ書
chapter: 26
verses: "3"
speaker: イザヤ
theme: ['平安', '信頼', '心を定める']
situation: ['心を定めたい', '完全な平安', '神を信頼する']
token_estimate: 23
---

# イザヤ書 26章3節

あなたは全き平安をもってこころざしの堅固なものを守られる。彼はあなたに信頼しているからである。