---
id: faith_010_parent
type: parent
book: ヘブル人への手紙
chapter: 11
verses: "1"
speaker: 著者不詳
theme: ['信仰', '確信', '証拠']
situation: ['信仰とは何か', '見えないものを信じる', '信仰の定義']
token_estimate: 20
---

# ヘブル人への手紙 11章1節

さて、信仰とは、望んでいる事がらを確信し、まだ見ていない事実を確認することである。