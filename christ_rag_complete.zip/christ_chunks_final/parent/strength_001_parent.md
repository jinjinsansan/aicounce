---
id: strength_001_parent
type: parent
book: ヨシュア記
chapter: 1
verses: "9"
speaker: 神
theme: ['勇気', '強さ', '神の臨在']
situation: ['恐れている', '勇気が欲しい', '新しい挑戦']
token_estimate: 40
---

# ヨシュア記 1章9節

わたしはあなたに命じたではないか。強く、また雄々しくあれ。恐れてはならない、おののいてはならない。あなたがどこへ行くにも、あなたの神、主が共におられるからである。