---
id: proverb_005_parent
type: parent
book: 箴言
chapter: 18
verses: "10"
speaker: ソロモン
theme: ['神の名', '守り', '安全']
situation: ['危険を感じる', '安全な場所が欲しい']
token_estimate: 17
---

# 箴言 18章10節

主の名は堅固なやぐらのようだ、正しい者はその中に走りこんで救われる。