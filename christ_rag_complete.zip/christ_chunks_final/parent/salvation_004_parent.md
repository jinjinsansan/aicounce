---
id: salvation_004_parent
type: parent
book: 使徒行伝
chapter: 4
verses: "12"
speaker: ペテロ
theme: ['救い', '唯一の名', 'キリスト']
situation: ['他の宗教は', 'キリストだけか', '救いの道']
token_estimate: 28
---

# 使徒行伝 4章12節

この人による以外に救はない。わたしたちを救いうる名は、これを別にしては、天下のだれにも与えられていないからである。