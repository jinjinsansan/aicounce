---
id: strength_004_child_13
type: child
parent_id: strength_004_parent
book: ピリピ人への手紙
chapter: 4
verses: "13"
theme: ['強さ', '可能性']
token_estimate: 15
---

# ピリピ人への手紙 4章13節

わたしを強くして下さるかたによって、何事でもすることができる。