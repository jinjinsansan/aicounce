---
id: love_003_child_16
type: child
parent_id: love_003_parent
book: ヨハネによる福音書
chapter: 3
verses: "16"
theme: ['神の愛', '永遠の命']
token_estimate: 31
---

# ヨハネによる福音書 3章16節

神はそのひとり子を賜わったほどに、この世を愛して下さった。それは御子を信じる者がひとりも滅びないで、永遠の命を得るためである。