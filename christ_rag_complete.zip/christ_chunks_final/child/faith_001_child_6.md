---
id: faith_001_child_6
type: child
parent_id: faith_001_parent
book: ヘブル人への手紙
chapter: 11
verses: "6"
theme: ['信仰', '神を喜ばせる']
token_estimate: 38
---

# ヘブル人への手紙 11章6節

信仰がなくては、神に喜ばれることはできない。なぜなら、神に来る者は、神のいますことと、ご自身を求める者に報いて下さることとを、必ず信じるはずだからである。