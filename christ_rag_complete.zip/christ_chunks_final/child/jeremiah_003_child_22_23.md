---
id: jeremiah_003_child_22_23
type: child
parent_id: jeremiah_003_parent
book: 哀歌
chapter: 3
verses: "22-23"
theme: ['神の憐れみ', '新しさ']
token_estimate: 28
---

# 哀歌 3章22-23節

主のいつくしみは絶えることがなく、そのあわれみは尽きることがない。これは朝ごとに新しく、あなたの真実さは大きい。