---
id: psalm_130_child_1_2
type: child
parent_id: psalm_130_parent
book: 詩篇
chapter: 130
verses: "1-2"
theme: ['深い淵', '叫び']
token_estimate: 18
---

# 詩篇 130章1-2節

主よ、わたしは深い淵からあなたに呼ばわる。主よ、どうかわが声を聞きたまえ。