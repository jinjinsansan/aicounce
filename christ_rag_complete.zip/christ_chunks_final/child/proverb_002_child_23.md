---
id: proverb_002_child_23
type: child
parent_id: proverb_002_parent
book: 箴言
chapter: 4
verses: "23"
theme: ['心', '守る']
token_estimate: 18
---

# 箴言 4章23節

油断することなく、あなたの心を守れ、命の泉は、これからわき出るからである。