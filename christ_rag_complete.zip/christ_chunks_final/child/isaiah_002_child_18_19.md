---
id: isaiah_002_child_18_19
type: child
parent_id: isaiah_002_parent
book: イザヤ書
chapter: 43
verses: "18-19"
theme: ['新しいこと', '希望']
token_estimate: 40
---

# イザヤ書 43章18-19節

あなたがたは、さきの事を思い出してはならない、また関しの事を考えてはならない。見よ、わたしは新しい事をする。やがてそれは起こる、あなたがたはそれを知らないのか。