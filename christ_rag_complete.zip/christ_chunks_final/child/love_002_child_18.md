---
id: love_002_child_18
type: child
parent_id: love_002_parent
book: ヨハネの第一の手紙
chapter: 4
verses: "18"
theme: ['愛', '恐れ']
token_estimate: 27
---

# ヨハネの第一の手紙 4章18節

愛には恐れがない。完全な愛は恐れをとり除く。恐れには懲罰が伴い、恐れる者には、愛が全うされていないのである。