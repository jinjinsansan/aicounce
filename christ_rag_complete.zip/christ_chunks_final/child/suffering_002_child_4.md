---
id: suffering_002_child_4
type: child
parent_id: suffering_002_parent
book: コリント人への第二の手紙
chapter: 1
verses: "4"
theme: ['慰め', '他者への奉仕']
token_estimate: 31
---

# コリント人への第二の手紙 1章4節

わたしたち自身も、神に慰めていただくその慰めをもって、あらゆる患難の中にある人々を慰めることができるようにして下さるのである。