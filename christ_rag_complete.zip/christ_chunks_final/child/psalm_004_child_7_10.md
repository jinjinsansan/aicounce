---
id: psalm_004_child_7_10
type: child
parent_id: psalm_004_parent
book: 詩篇
chapter: 139
verses: "7-10"
theme: ['遍在', '逃れられない']
token_estimate: 39
---

# 詩篇 139章7-10節

わたしはどこへ行って、あなたのみたまを離れましょうか。わたしはどこへ行って、あなたのみ前をのがれましょうか。わたしが天にのぼっても、あなたはそこにおられます。