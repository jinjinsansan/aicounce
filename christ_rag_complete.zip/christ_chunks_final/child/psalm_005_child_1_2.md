---
id: psalm_005_child_1_2
type: child
parent_id: psalm_005_parent
book: 詩篇
chapter: 103
verses: "1-2"
theme: ['感謝', '賛美']
token_estimate: 35
---

# 詩篇 103章1-2節

わがたましいよ、主をほめよ。わがうちなるすべてのものよ、その聖なるみ名をほめよ。わがたましいよ、主をほめよ。そのすべてのめぐみを心にとめよ。