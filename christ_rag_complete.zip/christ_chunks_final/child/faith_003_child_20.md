---
id: faith_003_child_20
type: child
parent_id: faith_003_parent
book: マタイによる福音書
chapter: 17
verses: "20"
theme: ['信仰', '可能性']
token_estimate: 40
---

# マタイによる福音書 17章20節

もし、からし種一粒ほどの信仰があるなら、この山にむかって『ここからあそこに移れ』と言えば、移るであろう。このように、あなたがたにできない事は、何もないであろう。