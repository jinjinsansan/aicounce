---
id: psalm_005_child_3_5
type: child
parent_id: psalm_005_parent
book: 詩篇
chapter: 103
verses: "3-5"
theme: ['赦し', '恵み']
token_estimate: 36
---

# 詩篇 103章3-5節

主はあなたのすべての不義をゆるし、あなたのすべての病をいやし、あなたのいのちを穴から関いいだし、いつくしみと、あわれみとをあなたにこうむらせる。