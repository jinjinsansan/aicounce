---
id: hope_002_child_13
type: child
parent_id: hope_002_parent
book: ローマ人への手紙
chapter: 15
verses: "13"
theme: ['希望', '祝福']
token_estimate: 34
---

# ローマ人への手紙 15章13節

どうか、望みの神が、信仰から来るあらゆる喜びと平安とを、あなたがたに満たし、聖霊の力によって、あなたがたを望みにあふれさせて下さるように。