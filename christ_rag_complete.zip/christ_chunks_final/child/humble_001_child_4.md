---
id: humble_001_child_4
type: child
parent_id: humble_001_parent
book: ピリピ人への手紙
chapter: 2
verses: "4"
theme: ['他者への配慮']
token_estimate: 14
---

# ピリピ人への手紙 2章4節

おのおの、自分のことばかりでなく、他人のことも考えなさい。