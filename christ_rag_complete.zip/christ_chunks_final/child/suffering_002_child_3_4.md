---
id: suffering_002_child_3_4
type: child
parent_id: suffering_002_parent
book: コリント人への第二の手紙
chapter: 1
verses: "3-4"
theme: ['慰め', '神の憐れみ']
token_estimate: 24
---

# コリント人への第二の手紙 1章3-4節

あわれみの父、慰めを豊かに下さる神。神は、いかなる患難の中にいる時でもわたしたちを慰めて下さる。