---
id: peace_003_child_3
type: child
parent_id: peace_003_parent
book: イザヤ書
chapter: 26
verses: "3"
theme: ['平安', '信頼']
token_estimate: 23
---

# イザヤ書 26章3節

あなたは全き平安をもってこころざしの堅固なものを守られる。彼はあなたに信頼しているからである。