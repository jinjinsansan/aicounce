---
id: guidance_003_child_21
type: child
parent_id: guidance_003_parent
book: イザヤ書
chapter: 30
verses: "21"
theme: ['導き', '神の声']
token_estimate: 28
---

# イザヤ書 30章21節

また、あなたが右に行き、あるいは左に行く時、あなたの耳は、うしろから「これは道だ、これに歩め」と言う言葉を聞く。