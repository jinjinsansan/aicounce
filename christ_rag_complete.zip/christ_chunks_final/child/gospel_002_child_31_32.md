---
id: gospel_002_child_31_32
type: child
parent_id: gospel_002_parent
book: ヨハネによる福音書
chapter: 8
verses: "31-32"
theme: ['真理', '自由']
token_estimate: 38
---

# ヨハネによる福音書 8章31-32節

もしわたしの言葉のうちにとどまっておるなら、あなたがたは本当に弟子なのである。また真理を知るであろう。そして真理は、あなたがたに自由を得させるであろう。