---
id: sermon_005_child_24_25
type: child
parent_id: sermon_005_parent
book: マタイによる福音書
chapter: 7
verses: "24-25"
theme: ['岩', '実践']
token_estimate: 48
---

# マタイによる福音書 7章24-25節

それで、わたしのこれらの言葉を聞いて行うものを、岩の上に自分の家を建てた賢い人に関えよう。雨が降り、洪水が押し寄せ、風が吹いてその家に関打っても、倒れることはない。岩を土台としているからである。