---
id: proverb_003_child_3
type: child
parent_id: proverb_003_parent
book: 箴言
chapter: 16
verses: "3"
theme: ['委ねる', '成功']
token_estimate: 21
---

# 箴言 16章3節

あなたのなすべき事を主にゆだねよ、そうすれば、あなたの計るところは成り立つであろう。