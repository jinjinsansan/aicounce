---
id: words_002_child_4
type: child
parent_id: words_002_parent
book: 箴言
chapter: 15
verses: "4"
theme: ['言葉', '癒し']
token_estimate: 12
---

# 箴言 15章4節

優しい舌は命の木である、乱暴な言葉は魂を傷つける。