---
id: strength_003_child_1
type: child
parent_id: strength_003_parent
book: 詩篇
chapter: 27
verses: "1"
theme: ['光', '救い']
token_estimate: 29
---

# 詩篇 27章1節

主はわたしの光、わたしの救である、わたしはだれを恐れよう。主はわたしの命のとりでである。わたしはだれをおじ恐れよう。