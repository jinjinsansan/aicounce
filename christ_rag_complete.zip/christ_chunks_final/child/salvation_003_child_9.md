---
id: salvation_003_child_9
type: child
parent_id: salvation_003_parent
book: ローマ人への手紙
chapter: 10
verses: "9"
theme: ['告白', '信仰']
token_estimate: 32
---

# ローマ人への手紙 10章9節

すなわち、自分の口で、イエスは主であると告白し、自分の心で、神が死人の中からイエスをよみがえらせたと信じるなら、あなたは救われる。