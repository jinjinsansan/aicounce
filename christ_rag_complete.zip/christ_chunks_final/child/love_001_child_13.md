---
id: love_001_child_13
type: child
parent_id: love_001_parent
book: コリント人への第一の手紙
chapter: 13
verses: "13"
theme: ['愛', '信仰', '希望']
token_estimate: 28
---

# コリント人への第一の手紙 13章13節

このように、いつまでも存続するものは、信仰と希望と愛と、この三つである。このうちで最も大いなるものは、愛である。