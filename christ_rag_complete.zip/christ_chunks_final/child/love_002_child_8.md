---
id: love_002_child_8
type: child
parent_id: love_002_parent
book: ヨハネの第一の手紙
chapter: 4
verses: "8"
theme: ['神の本質', '愛']
token_estimate: 10
---

# ヨハネの第一の手紙 4章8節

愛さない者は、神を知らない。神は愛である。