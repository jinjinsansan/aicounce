---
id: salvation_002_child_8
type: child
parent_id: salvation_002_parent
book: エペソ人への手紙
chapter: 2
verses: "8"
theme: ['恵み', '信仰']
token_estimate: 31
---

# エペソ人への手紙 2章8節

あなたがたの救われたのは、実に、恵みにより、信仰によるのである。それは、あなたがた自身から出たものではなく、神の賜物である。