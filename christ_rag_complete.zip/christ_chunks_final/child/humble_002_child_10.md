---
id: humble_002_child_10
type: child
parent_id: humble_002_parent
book: ヤコブの手紙
chapter: 4
verses: "10"
theme: ['謙遜', '高くされる']
token_estimate: 21
---

# ヤコブの手紙 4章10節

主のみまえにへりくだりなさい。そうすれば、主は、あなたがたを高くして下さるであろう。