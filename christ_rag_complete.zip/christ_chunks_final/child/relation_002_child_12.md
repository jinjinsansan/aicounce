---
id: relation_002_child_12
type: child
parent_id: relation_002_parent
book: コロサイ人への手紙
chapter: 3
verses: "12"
theme: ['謙遜', '愛']
token_estimate: 30
---

# コロサイ人への手紙 3章12節

あなたがたは、神に選ばれた者、聖なる、愛されている者であるから、あわれみの心、慈愛、謙そん、柔和、寛容を身に着けなさい。