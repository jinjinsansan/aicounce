---
id: psalm_005_child_8
type: child
parent_id: psalm_005_parent
book: 詩篇
chapter: 103
verses: "8"
theme: ['神の性質', 'あわれみ']
token_estimate: 19
---

# 詩篇 103章8節

主はあわれみに富み、めぐみふかく、怒ることおそく、いつくしみ関かなるかたです。