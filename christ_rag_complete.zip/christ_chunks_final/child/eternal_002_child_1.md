---
id: eternal_002_child_1
type: child
parent_id: eternal_002_parent
book: 黙示録
chapter: 21
verses: "1"
theme: ['新天新地', '新しさ']
token_estimate: 22
---

# 黙示録 21章1節

わたしはまた、新しい天と新しい地とを見た。先の天と地とは消え去り、海もなくなってしまった。