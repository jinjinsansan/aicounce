---
id: sermon_004_child_3_5
type: child
parent_id: sermon_004_parent
book: マタイによる福音書
chapter: 7
verses: "3-5"
theme: ['自己吟味', '謙遜']
token_estimate: 29
---

# マタイによる福音書 7章3-5節

なぜ、兄弟の目にあるちりを見ながら、自分の目にある梁を認めないのか。偽善者よ、まず自分の目から梁を取りのけるがよい。