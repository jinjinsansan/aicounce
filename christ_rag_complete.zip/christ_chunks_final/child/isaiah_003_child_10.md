---
id: isaiah_003_child_10
type: child
parent_id: isaiah_003_parent
book: イザヤ書
chapter: 54
verses: "10"
theme: ['神の愛', '契約']
token_estimate: 30
---

# イザヤ書 54章10節

山は移り、丘は動いても、わがいつくしみはあなたから離れず、平和の契約は動くことがないと、あなたをあわれまれる主は言われる。