---
id: sermon_002_child_13
type: child
parent_id: sermon_002_parent
book: マタイによる福音書
chapter: 5
verses: "13"
theme: ['塩', '使命']
token_estimate: 23
---

# マタイによる福音書 5章13節

あなたがたは、地の塩である。もし塩のききめがなくなったら、何によってその味が関けるだろうか。