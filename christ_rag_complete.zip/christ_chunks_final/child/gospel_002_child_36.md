---
id: gospel_002_child_36
type: child
parent_id: gospel_002_parent
book: ヨハネによる福音書
chapter: 8
verses: "36"
theme: ['自由']
token_estimate: 24
---

# ヨハネによる福音書 8章36節

だから、もし子があなたがたに自由を得させるならば、あなたがたは、本当に、自由な者となるのである。