---
id: faith_012_child_17
type: child
parent_id: faith_012_parent
book: ローマ人への手紙
chapter: 10
verses: "17"
theme: ['信仰', '御言葉']
token_estimate: 21
---

# ローマ人への手紙 10章17節

したがって、信仰は聞くことによるのであり、聞くことはキリストの言葉から来るのである。