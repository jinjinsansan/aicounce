---
id: joy_001_child_4
type: child
parent_id: joy_001_parent
book: ピリピ人への手紙
chapter: 4
verses: "4"
theme: ['喜び']
token_estimate: 14
---

# ピリピ人への手紙 4章4節

主にあっていつも喜びなさい。繰り返して言うが、喜びなさい。