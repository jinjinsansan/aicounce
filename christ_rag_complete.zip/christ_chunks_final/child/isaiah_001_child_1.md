---
id: isaiah_001_child_1
type: child
parent_id: isaiah_001_parent
book: イザヤ書
chapter: 43
verses: "1"
theme: ['贖い', '所属']
token_estimate: 22
---

# イザヤ書 43章1節

恐れるな、わたしはあなたをあがなった。わたしはあなたの名を呼んだ、あなたはわたしのものだ。