---
id: love_004_child_35
type: child
parent_id: love_004_parent
book: ローマ人への手紙
chapter: 8
verses: "35"
theme: ['神の愛', '試練']
token_estimate: 26
---

# ローマ人への手紙 8章35節

だれが、キリストの愛からわたしたちを離れさせるのか。患難か、苦悩か、迫害か、飢えか、裸か、危難か、剣か。