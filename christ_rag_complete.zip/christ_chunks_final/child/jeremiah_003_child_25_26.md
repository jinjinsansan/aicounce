---
id: jeremiah_003_child_25_26
type: child
parent_id: jeremiah_003_parent
book: 哀歌
chapter: 3
verses: "25-26"
theme: ['待つ', '沈黙']
token_estimate: 26
---

# 哀歌 3章25-26節

主はおのれを待ち望む者にむかい、おのれを尋ね求める者に良い。主の救いを黙って待ち望むのは良いことである。