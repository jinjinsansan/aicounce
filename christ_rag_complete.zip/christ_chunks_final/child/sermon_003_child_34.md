---
id: sermon_003_child_34
type: child
parent_id: sermon_003_parent
book: マタイによる福音書
chapter: 6
verses: "34"
theme: ['今日', '心配']
token_estimate: 31
---

# マタイによる福音書 6章34節

だから、あすのことを思いわずらうな。あすのことは、あす自身が思いわずらうであろう。一日の苦労は、その日一日だけで十分である。