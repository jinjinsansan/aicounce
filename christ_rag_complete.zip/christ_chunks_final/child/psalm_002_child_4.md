---
id: psalm_002_child_4
type: child
parent_id: psalm_002_parent
book: 詩篇
chapter: 91
verses: "4"
theme: ['守り', '神の翼']
token_estimate: 27
---

# 詩篇 91章4節

主はその羽をもって、あなたをおおわれる。あなたはその翼の下に避け所を得る。そのまことは大盾、また小盾である。