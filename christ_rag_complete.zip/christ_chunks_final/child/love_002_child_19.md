---
id: love_002_child_19
type: child
parent_id: love_002_parent
book: ヨハネの第一の手紙
chapter: 4
verses: "19"
theme: ['神の愛', '応答']
token_estimate: 18
---

# ヨハネの第一の手紙 4章19節

わたしたちが愛し合うのは、神がまずわたしたちを愛して下さったからである。