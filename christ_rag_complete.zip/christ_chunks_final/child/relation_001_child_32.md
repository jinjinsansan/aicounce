---
id: relation_001_child_32
type: child
parent_id: relation_001_parent
book: エペソ人への手紙
chapter: 4
verses: "32"
theme: ['赦し', '優しさ']
token_estimate: 31
---

# エペソ人への手紙 4章32節

互に情け深く、あわれみ深い者となり、神がキリストにあってあなたがたをゆるして下さったように、あなたがたも互にゆるし合いなさい。