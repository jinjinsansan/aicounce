---
id: psalm_004_child_17_18
type: child
parent_id: psalm_004_parent
book: 詩篇
chapter: 139
verses: "17-18"
theme: ['神の思い', '尊い']
token_estimate: 25
---

# 詩篇 139章17-18節

神よ、あなたのもろもろのみ思いは、なんとわたしに関いことでしょう。その関計のなんと広大なことでしょう。