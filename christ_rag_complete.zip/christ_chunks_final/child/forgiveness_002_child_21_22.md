---
id: forgiveness_002_child_21_22
type: child
parent_id: forgiveness_002_parent
book: マタイによる福音書
chapter: 18
verses: "21-22"
theme: ['赦し', '回数']
token_estimate: 54
---

# マタイによる福音書 18章21-22節

ペテロがイエスのもとにきて言った、「主よ、兄弟がわたしに対して罪を犯した場合、幾たびゆるさねばなりませんか。七たびまでですか」。イエスは彼に言われた、「わたしは七たびまでとは言わない。七たびを七十倍するまでにしなさい。