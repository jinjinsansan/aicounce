---
id: forgiveness_003_child_12
type: child
parent_id: forgiveness_003_parent
book: コロサイ人への手紙
chapter: 3
verses: "12"
theme: ['神に選ばれた者', '徳']
token_estimate: 32
---

# コロサイ人への手紙 3章12節

だから、あなたがたは、神に選ばれた者、聖なる、愛されている者であるから、あわれみの心、慈愛、謙そん、柔和、寛容を身に着けなさい。