---
id: work_002_child_4
type: child
parent_id: work_002_parent
book: 伝道の書
chapter: 3
verses: "4"
theme: ['感情の時']
token_estimate: 16
---

# 伝道の書 3章4節

泣くに時があり、笑うに時があり、悲しむに時があり、踊るに時がある。