---
id: relation_002_child_13
type: child
parent_id: relation_002_parent
book: コロサイ人への手紙
chapter: 3
verses: "13"
theme: ['赦し']
token_estimate: 36
---

# コロサイ人への手紙 3章13節

互に忍びあい、もし互に責むべきことがあれば、ゆるし合いなさい。主もあなたがたをゆるして下さったのだから、そのように、あなたがたもゆるし合いなさい。