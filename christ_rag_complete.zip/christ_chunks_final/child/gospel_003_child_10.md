---
id: gospel_003_child_10
type: child
parent_id: gospel_003_parent
book: ヨハネによる福音書
chapter: 10
verses: "10"
theme: ['豊かな命']
token_estimate: 15
---

# ヨハネによる福音書 10章10節

わたしがきたのは、羊に命を得させ、豊かに得させるためである。