---
id: words_001_child_5_6
type: child
parent_id: words_001_parent
book: ヤコブの手紙
chapter: 3
verses: "5-6"
theme: ['舌', '力']
token_estimate: 29
---

# ヤコブの手紙 3章5-6節

舌は小さな器官ではあるが、よく大言壮語する。見よ、ごく小さな火でも、非常に大きな森を燃やすではないか。舌は火である。