---
id: gospel_004_child_5
type: child
parent_id: gospel_004_parent
book: ヨハネによる福音書
chapter: 15
verses: "5"
theme: ['実を結ぶ']
token_estimate: 51
---

# ヨハネによる福音書 15章5節

わたしはぶどうの木、あなたがたは枝である。もし人がわたしにつながっており、またわたしがその人とつながっておれば、その人は多くの実を結ぶようになる。わたしから離れては、あなたがたは何一つできないからである。