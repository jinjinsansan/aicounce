---
id: relation_002_child_14
type: child
parent_id: relation_002_parent
book: コロサイ人への手紙
chapter: 3
verses: "14"
theme: ['愛']
token_estimate: 19
---

# コロサイ人への手紙 3章14節

これらいっさいのものの上に、愛を加えなさい。愛は、すべてを完全に結ぶ帯である。