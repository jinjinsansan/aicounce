---
id: gospel_002_child_34
type: child
parent_id: gospel_002_parent
book: ヨハネによる福音書
chapter: 8
verses: "34"
theme: ['罪', '奴隷']
token_estimate: 16
---

# ヨハネによる福音書 8章34節

よくよくあなたがたに言っておく。すべて罪を犯す者は罪の奴隷である。