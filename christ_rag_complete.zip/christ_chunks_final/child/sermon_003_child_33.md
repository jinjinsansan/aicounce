---
id: sermon_003_child_33
type: child
parent_id: sermon_003_parent
book: マタイによる福音書
chapter: 6
verses: "33"
theme: ['優先順位', '神の国']
token_estimate: 23
---

# マタイによる福音書 6章33節

まず神の国と神の義とを求めなさい。そうすれば、これらのものは、すべて添えて与えられるであろう。