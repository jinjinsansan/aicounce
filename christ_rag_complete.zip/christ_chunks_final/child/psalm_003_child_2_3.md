---
id: psalm_003_child_2_3
type: child
parent_id: psalm_003_parent
book: 詩篇
chapter: 46
verses: "2-3"
theme: ['恐れ', '信頼']
token_estimate: 17
---

# 詩篇 46章2-3節

このゆえに、たとい地は変り、山は海の真中に移るとも、われらは恐れない。