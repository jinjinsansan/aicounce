---
id: gospel_001_child_11
type: child
parent_id: gospel_001_parent
book: マタイによる福音書
chapter: 7
verses: "11"
theme: ['神の良さ']
token_estimate: 46
---

# マタイによる福音書 7章11節

このように、あなたがたは悪い者であっても、自分の子供には、良い贈り物をすることを知っているとすれば、天にいますあなたがたの父はなおさら、求めてくる者に良いものを下さらないことがあろうか。