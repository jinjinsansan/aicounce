---
id: hope_001_child_12_13
type: child
parent_id: hope_001_parent
book: エレミヤ書
chapter: 29
verses: "12-13"
theme: ['祈り', '神を求める']
token_estimate: 45
---

# エレミヤ書 29章12-13節

その時、あなたがたはわたしに呼ばわり、来て、わたしに祈る。わたしはあなたがたの祈を聞く。あなたがたはわたしを尋ね求めて、わたしに会う。もしあなたがたが一心にわたしを尋ね求めるならば、