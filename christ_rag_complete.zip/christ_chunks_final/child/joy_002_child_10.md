---
id: joy_002_child_10
type: child
parent_id: joy_002_parent
book: ネヘミヤ記
chapter: 8
verses: "10"
theme: ['喜び', '力']
token_estimate: 13
---

# ネヘミヤ記 8章10節

憂えてはならない。主を喜ぶことはあなたがたの力です。