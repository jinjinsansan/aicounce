---
id: humble_002_child_6
type: child
parent_id: humble_002_parent
book: ヤコブの手紙
chapter: 4
verses: "6"
theme: ['謙遜', '恵み']
token_estimate: 12
---

# ヤコブの手紙 4章6節

神は高ぶる者をしりぞけ、へりくだる者に恵みを賜う。