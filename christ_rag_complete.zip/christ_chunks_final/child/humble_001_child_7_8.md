---
id: humble_001_child_7_8
type: child
parent_id: humble_001_parent
book: ピリピ人への手紙
chapter: 2
verses: "7-8"
theme: ['キリストの模範', '謙遜']
token_estimate: 35
---

# ピリピ人への手紙 2章7-8節

かえって、おのれをむなしうして僕のかたちをとり、人間の姿になられた。おのれを低くして、死に至るまで、しかも十字架の死に至るまで従順であられた。