---
id: strength_002_child_10
type: child
parent_id: strength_002_parent
book: イザヤ書
chapter: 41
verses: "10"
theme: ['恐れ', '神の助け']
token_estimate: 42
---

# イザヤ書 41章10節

恐れてはならない、わたしはあなたと共にいる。驚いてはならない、わたしはあなたの神である。わたしはあなたを強くし、あなたを助け、わが勝利の右の手をもって、あなたをささえる。