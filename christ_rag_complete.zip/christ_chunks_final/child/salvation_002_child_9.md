---
id: salvation_002_child_9
type: child
parent_id: salvation_002_parent
book: エペソ人への手紙
chapter: 2
verses: "9"
theme: ['行い', '誇り']
token_estimate: 18
---

# エペソ人への手紙 2章9節

決して行いによるのではない。それは、だれも誇ることがないためなのである。