---
id: psalm_003_child_1
type: child
parent_id: psalm_003_parent
book: 詩篇
chapter: 46
verses: "1"
theme: ['避け所', '助け']
token_estimate: 15
---

# 詩篇 46章1節

神はわれらの避け所また力である。悩める時のいと近き助けである。