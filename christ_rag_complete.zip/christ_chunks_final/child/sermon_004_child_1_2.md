---
id: sermon_004_child_1_2
type: child
parent_id: sermon_004_parent
book: マタイによる福音書
chapter: 7
verses: "1-2"
theme: ['裁き', '基準']
token_estimate: 38
---

# マタイによる福音書 7章1-2節

人をさばくな。自分がさばかれないためである。あなたがたがさばくそのさばきで、自分もさばかれ、あなたがたの量るそのはかりで、自分にも量り与えられるであろう。