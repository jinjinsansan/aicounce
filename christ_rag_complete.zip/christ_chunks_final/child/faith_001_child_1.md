---
id: faith_001_child_1
type: child
parent_id: faith_001_parent
book: ヘブル人への手紙
chapter: 11
verses: "1"
theme: ['信仰', '確信']
token_estimate: 20
---

# ヘブル人への手紙 11章1節

さて、信仰とは、望んでいる事がらを確信し、まだ見ていない事実を確認することである。