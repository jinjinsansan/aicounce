---
id: micah_002_child_18
type: child
parent_id: micah_002_parent
book: ミカ書
chapter: 7
verses: "18"
theme: ['赦し', '神の憐れみ']
token_estimate: 40
---

# ミカ書 7章18節

あなたのような神がほかにあろうか。あなたは不義をゆるし、その嗣業の残りの者のためにとがをゆるし、いつまでも怒りを抱いていることをせず、いつくしむことを喜ばれる。