---
id: work_001_child_24
type: child
parent_id: work_001_parent
book: コロサイ人への手紙
chapter: 3
verses: "24"
theme: ['報い', '仕える']
token_estimate: 34
---

# コロサイ人への手紙 3章24節

あなたがたが知っているとおり、あなたがたは御国をつぐことを、報いとして主から受けるであろう。あなたがたは、主キリストに仕えているのである。