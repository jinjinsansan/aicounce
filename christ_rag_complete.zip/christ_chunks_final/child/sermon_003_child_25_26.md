---
id: sermon_003_child_25_26
type: child
parent_id: sermon_003_parent
book: マタイによる福音書
chapter: 6
verses: "25-26"
theme: ['思い煩い', '神の養い']
token_estimate: 47
---

# マタイによる福音書 6章25-26節

何を食べようか、何を飲もうかと、自分の命のことで思いわずらい、何を着ようかと自分のからだのことで思いわずらうな。空の鳥を見るがよい。それだのに、あなたがたの天の父は彼らを養っていて下さる。