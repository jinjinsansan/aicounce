---
id: eternal_001_child_25
type: child
parent_id: eternal_001_parent
book: ヨハネによる福音書
chapter: 11
verses: "25"
theme: ['復活', '命']
token_estimate: 19
---

# ヨハネによる福音書 11章25節

わたしはよみがえりであり、命である。わたしを信じる者は、たとい死んでも生きる。