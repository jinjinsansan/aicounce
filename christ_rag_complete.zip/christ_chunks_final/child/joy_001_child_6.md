---
id: joy_001_child_6
type: child
parent_id: joy_001_parent
book: ピリピ人への手紙
chapter: 4
verses: "6"
theme: ['祈り', '感謝']
token_estimate: 31
---

# ピリピ人への手紙 4章6節

何事も思い煩ってはならない。ただ、事ごとに、感謝をもって祈と願いとをささげ、あなたがたの求めるところを神に申し上げるがよい。