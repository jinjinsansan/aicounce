---
id: psalm_001_child_4
type: child
parent_id: psalm_001_parent
book: 詩篇
chapter: 23
verses: "4"
theme: ['恐れ', '守り']
token_estimate: 24
---

# 詩篇 23章4節

たといわたしは死の陰の谷を歩むとも、わざわいを恐れません。あなたがわたしと共におられるからです。