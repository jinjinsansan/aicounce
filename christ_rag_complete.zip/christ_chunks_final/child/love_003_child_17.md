---
id: love_003_child_17
type: child
parent_id: love_003_parent
book: ヨハネによる福音書
chapter: 3
verses: "17"
theme: ['救い', '裁き']
token_estimate: 24
---

# ヨハネによる福音書 3章17節

神が御子を世につかわされたのは、世をさばくためではなく、御子によって、この世が救われるためである。