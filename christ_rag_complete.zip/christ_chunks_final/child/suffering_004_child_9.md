---
id: suffering_004_child_9
type: child
parent_id: suffering_004_parent
book: コリント人への第二の手紙
chapter: 12
verses: "9"
theme: ['恵み', '力']
token_estimate: 25
---

# コリント人への第二の手紙 12章9節

主が言われた、「わたしの恵みはあなたに対して十分である。わたしの力は弱いところに完全にあらわれる」。