---
id: faith_002_child_23
type: child
parent_id: faith_002_parent
book: マルコによる福音書
chapter: 9
verses: "23"
theme: ['信仰', '可能性']
token_estimate: 21
---

# マルコによる福音書 9章23節

イエスは彼に言われた、「もしできれば、と言うのか。信ずる者には、どんな事でもできる」。