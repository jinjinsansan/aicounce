---
id: peace_004_child_8
type: child
parent_id: peace_004_parent
book: 詩篇
chapter: 4
verses: "8"
theme: ['安眠', '安全']
token_estimate: 24
---

# 詩篇 4章8節

わたしは安らかに横になり、眠りにつきます。主よ、あなただけが安全にわたしを住まわせてくださいます。