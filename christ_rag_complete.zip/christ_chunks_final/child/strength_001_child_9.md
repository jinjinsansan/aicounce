---
id: strength_001_child_9
type: child
parent_id: strength_001_parent
book: ヨシュア記
chapter: 1
verses: "9"
theme: ['勇気', '神の臨在']
token_estimate: 40
---

# ヨシュア記 1章9節

わたしはあなたに命じたではないか。強く、また雄々しくあれ。恐れてはならない、おののいてはならない。あなたがどこへ行くにも、あなたの神、主が共におられるからである。