---
id: psalm_002_child_11_12
type: child
parent_id: psalm_002_parent
book: 詩篇
chapter: 91
verses: "11-12"
theme: ['天使', '守り']
token_estimate: 42
---

# 詩篇 91章11-12節

これは主があなたのために天使たちに命じて、あなたの歩むすべての道であなたを守らせられるからである。彼らはその手で、あなたをささえ、石に足を打ちつけることのないようにする。