---
id: guidance_001_child_8
type: child
parent_id: guidance_001_parent
book: 詩篇
chapter: 32
verses: "8"
theme: ['導き', '神の教え']
token_estimate: 23
---

# 詩篇 32章8節

わたしはあなたを教え、あなたの行くべき道を示し、わたしの目をあなたにとめて、さとすであろう。