---
id: peace_002_child_27
type: child
parent_id: peace_002_parent
book: ヨハネによる福音書
chapter: 14
verses: "27"
theme: ['平安', 'キリスト']
token_estimate: 42
---

# ヨハネによる福音書 14章27節

わたしは平安をあなたがたに残して行く。わたしの平安をあなたがたに与える。わたしが与えるのは、世が与えるようなものとは異なる。あなたがたは心を騒がせるな、またおじけるな。