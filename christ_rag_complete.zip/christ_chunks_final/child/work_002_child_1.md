---
id: work_002_child_1
type: child
parent_id: work_002_parent
book: 伝道の書
chapter: 3
verses: "1"
theme: ['時', '季節']
token_estimate: 15
---

# 伝道の書 3章1節

天が下のすべての事には季節があり、すべてのわざには時がある。