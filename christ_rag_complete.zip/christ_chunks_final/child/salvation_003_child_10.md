---
id: salvation_003_child_10
type: child
parent_id: salvation_003_parent
book: ローマ人への手紙
chapter: 10
verses: "10"
theme: ['義', '救い']
token_estimate: 16
---

# ローマ人への手紙 10章10節

なぜなら、人は心に信じて義とされ、口で告白して救われるからである。