---
id: forgiveness_003_child_13
type: child
parent_id: forgiveness_003_parent
book: コロサイ人への手紙
chapter: 3
verses: "13"
theme: ['赦し', '相互']
token_estimate: 29
---

# コロサイ人への手紙 3章13節

互にゆるし合いなさい。もし互に責むべきことがあれば、主があなたがたをゆるして下さったように、あなたがたもそうしなさい。