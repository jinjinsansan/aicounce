---
id: psalm_034_child_5
type: child
parent_id: psalm_034_parent
book: 詩篇
chapter: 34
verses: "5"
theme: ['希望', '光']
token_estimate: 19
---

# 詩篇 34章5節

主を仰ぎ見て、光を得よ、そうすれば、あなたがたの顔は、恥で赤くなることがない。