---
id: jeremiah_003_child_24
type: child
parent_id: jeremiah_003_parent
book: 哀歌
chapter: 3
verses: "24"
theme: ['希望']
token_estimate: 20
---

# 哀歌 3章24節

わが魂は言う、「主はわたしの受くべき分である、それゆえ、わたしは彼を待ち望む」と。