---
id: psalm_042_child_1_2
type: child
parent_id: psalm_042_parent
book: 詩篇
chapter: 42
verses: "1-2"
theme: ['神への渇き']
token_estimate: 29
---

# 詩篇 42章1-2節

神よ、しかが谷川を慕いあえぐように、わが魂もあなたを慕いあえぐ。わが魂はかわいているように神を慕い、いける神を慕う。