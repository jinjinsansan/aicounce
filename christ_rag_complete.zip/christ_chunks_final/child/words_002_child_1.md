---
id: words_002_child_1
type: child
parent_id: words_002_parent
book: 箴言
chapter: 15
verses: "1"
theme: ['言葉', '怒り']
token_estimate: 14
---

# 箴言 15章1節

柔らかい答は憤りをとどめ、激しい言葉は怒りをひきおこす。