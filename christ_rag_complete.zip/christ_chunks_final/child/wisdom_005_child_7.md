---
id: wisdom_005_child_7
type: child
parent_id: wisdom_005_parent
book: 箴言
chapter: 4
verses: "7"
theme: ['知恵', '優先']
token_estimate: 18
---

# 箴言 4章7節

知恵の初めはこれである、知恵を得よ、あなたが何を得るにしても、悟りを得よ。