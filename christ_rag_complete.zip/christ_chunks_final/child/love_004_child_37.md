---
id: love_004_child_37
type: child
parent_id: love_004_parent
book: ローマ人への手紙
chapter: 8
verses: "37"
theme: ['勝利', '神の愛']
token_estimate: 26
---

# ローマ人への手紙 8章37節

しかし、わたしたちを愛して下さったかたによって、わたしたちは、これらすべての事において勝ち得て余りがある。