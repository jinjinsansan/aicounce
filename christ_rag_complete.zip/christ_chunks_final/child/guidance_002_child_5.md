---
id: guidance_002_child_5
type: child
parent_id: guidance_002_parent
book: 詩篇
chapter: 37
verses: "5"
theme: ['委ねる', '信頼']
token_estimate: 15
---

# 詩篇 37章5節

あなたの道を主にゆだねよ。主に信頼せよ、主はそれをなしとげる。