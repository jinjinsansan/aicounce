---
id: micah_002_child_19
type: child
parent_id: micah_002_parent
book: ミカ書
chapter: 7
verses: "19"
theme: ['罪の赦し']
token_estimate: 27
---

# ミカ書 7章19節

あなたは再びわたしたちをあわれみ、われわれの不義を踏み付け、われわれのすべての罪を海の深みに投げ入れられる。