---
id: salvation_001_child_23
type: child
parent_id: salvation_001_parent
book: ローマ人への手紙
chapter: 3
verses: "23"
theme: ['罪', '普遍性']
token_estimate: 18
---

# ローマ人への手紙 3章23節

すなわち、すべての人は罪を犯したため、神の栄光を受けられなくなっており、