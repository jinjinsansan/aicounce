---
id: psalm_004_child_13_14
type: child
parent_id: psalm_004_parent
book: 詩篇
chapter: 139
verses: "13-14"
theme: ['造り主', '感謝']
token_estimate: 33
---

# 詩篇 139章13-14節

あなたはわが内臓をつくり、わが母の胎内でわたしを関み関まれました。わたしはあなたをほめたたえます。あなたは関いべく、くすしきかたです。