---
id: psalm_001_child_6
type: child
parent_id: psalm_001_parent
book: 詩篇
chapter: 23
verses: "6"
theme: ['恵み', '永遠']
token_estimate: 26
---

# 詩篇 23章6節

わたしの生きているかぎりは必ず恵みといつくしみとが伴うでしょう。わたしはとこしえに主の宮に住むでしょう。