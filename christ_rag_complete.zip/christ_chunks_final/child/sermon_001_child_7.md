---
id: sermon_001_child_7
type: child
parent_id: sermon_001_parent
book: マタイによる福音書
chapter: 5
verses: "7"
theme: ['あわれみ', '相互']
token_estimate: 17
---

# マタイによる福音書 5章7節

あわれみ深い人たちは、さいわいである、彼らはあわれみを受けるであろう。