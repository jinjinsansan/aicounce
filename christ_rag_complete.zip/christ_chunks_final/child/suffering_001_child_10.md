---
id: suffering_001_child_10
type: child
parent_id: suffering_001_parent
book: ペテロの第一の手紙
chapter: 5
verses: "10"
theme: ['苦難', '回復']
token_estimate: 41
---

# ペテロの第一の手紙 5章10節

あなたがたをキリストにある永遠の栄光に招き入れて下さったあふるる恵みの神は、しばらくの苦しみの後、あなたがたをいやし、強め、力づけ、不動のものとして下さるであろう。