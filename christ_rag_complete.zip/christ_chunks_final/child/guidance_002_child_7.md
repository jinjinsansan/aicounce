---
id: guidance_002_child_7
type: child
parent_id: guidance_002_parent
book: 詩篇
chapter: 37
verses: "7"
theme: ['忍耐', '待つ']
token_estimate: 10
---

# 詩篇 37章7節

主の前にもだし、耐え忍びて主を待ち望め。