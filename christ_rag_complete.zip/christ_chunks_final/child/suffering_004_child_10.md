---
id: suffering_004_child_10
type: child
parent_id: suffering_004_parent
book: コリント人への第二の手紙
chapter: 12
verses: "10"
theme: ['弱さ', '強さ']
token_estimate: 11
---

# コリント人への第二の手紙 12章10節

わたしが弱い時にこそ、わたしは強いからである。