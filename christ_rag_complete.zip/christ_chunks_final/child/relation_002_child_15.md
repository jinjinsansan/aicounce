---
id: relation_002_child_15
type: child
parent_id: relation_002_parent
book: コロサイ人への手紙
chapter: 3
verses: "15"
theme: ['平和']
token_estimate: 14
---

# コロサイ人への手紙 3章15節

キリストの平和が、あなたがたの心を支配するようにしなさい。