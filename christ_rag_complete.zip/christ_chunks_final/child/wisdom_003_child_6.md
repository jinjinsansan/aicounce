---
id: wisdom_003_child_6
type: child
parent_id: wisdom_003_parent
book: 箴言
chapter: 3
verses: "6"
theme: ['導き', '認める']
token_estimate: 17
---

# 箴言 3章6節

すべての道で主を認めよ、そうすれば、主はあなたの道をまっすぐにされる。