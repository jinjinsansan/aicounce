---
id: gospel_003_child_11
type: child
parent_id: gospel_003_parent
book: ヨハネによる福音書
chapter: 10
verses: "11"
theme: ['良い羊飼い', '自己犠牲']
token_estimate: 14
---

# ヨハネによる福音書 10章11節

わたしは良い羊飼である。良い羊飼は、羊のために命を捨てる。