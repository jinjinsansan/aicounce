---
id: gospel_001_child_7_8
type: child
parent_id: gospel_001_parent
book: マタイによる福音書
chapter: 7
verses: "7-8"
theme: ['祈り', '求める']
token_estimate: 50
---

# マタイによる福音書 7章7-8節

求めよ、そうすれば、与えられるであろう。捜せ、そうすれば、見いだすであろう。門をたたけ、そうすれば、あけてもらえるであろう。すべて求める者は得、捜す者は見いだし、門をたたく者はあけてもらえるからである。