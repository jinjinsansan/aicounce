---
id: work_001_child_23
type: child
parent_id: work_001_parent
book: コロサイ人への手紙
chapter: 3
verses: "23"
theme: ['働き', '心']
token_estimate: 18
---

# コロサイ人への手紙 3章23節

何をするにも、人に対してではなく、主に対してするように、心から働きなさい。