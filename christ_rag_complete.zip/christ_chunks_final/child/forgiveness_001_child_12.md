---
id: forgiveness_001_child_12
type: child
parent_id: forgiveness_001_parent
book: マタイによる福音書
chapter: 6
verses: "12"
theme: ['赦し', '祈り']
token_estimate: 21
---

# マタイによる福音書 6章12節

わたしたちに負債のある者をゆるしましたように、わたしたちの負債をもおゆるしください。