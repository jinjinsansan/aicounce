---
id: hope_001_child_11
type: child
parent_id: hope_001_parent
book: エレミヤ書
chapter: 29
verses: "11"
theme: ['神の計画', '希望']
token_estimate: 50
---

# エレミヤ書 29章11節

主は言われる、わたしがあなたがたに対していだいている計画はわたしが知っている。それは災を与えようというのではなく、平安を与えようとするものであり、あなたがたに将来を与え、希望を与えようとするものである。