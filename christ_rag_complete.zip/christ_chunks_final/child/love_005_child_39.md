---
id: love_005_child_39
type: child
parent_id: love_005_parent
book: マタイによる福音書
chapter: 22
verses: "39"
theme: ['隣人愛', '自己愛']
token_estimate: 17
---

# マタイによる福音書 22章39節

第二もこれと同様である、『自分を愛するようにあなたの隣り人を愛せよ』。