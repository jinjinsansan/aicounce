---
id: psalm_001_child_1
type: child
parent_id: psalm_001_parent
book: 詩篇
chapter: 23
verses: "1"
theme: ['牧者', '満足']
token_estimate: 13
---

# 詩篇 23章1節

主はわたしの牧者であって、わたしには乏しいことがない。