---
id: jeremiah_002_child_3
type: child
parent_id: jeremiah_002_parent
book: エレミヤ書
chapter: 31
verses: "3"
theme: ['永遠の愛']
token_estimate: 24
---

# エレミヤ書 31章3節

わたしは変わらぬ愛をもってあなたを愛した。それゆえ、わたしは絶えずあなたにいつくしみを施している。