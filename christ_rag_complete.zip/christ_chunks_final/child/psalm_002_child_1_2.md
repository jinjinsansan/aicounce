---
id: psalm_002_child_1_2
type: child
parent_id: psalm_002_parent
book: 詩篇
chapter: 91
verses: "1-2"
theme: ['避け所', '信頼']
token_estimate: 32
---

# 詩篇 91章1-2節

いと高き者のもとにある隠れ場に住む人、全能者の陰にやどる人は主に言うであろう、「わが避け所、わが城、わが信頼しまつるわが神」と。