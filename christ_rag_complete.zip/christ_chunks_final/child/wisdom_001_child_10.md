---
id: wisdom_001_child_10
type: child
parent_id: wisdom_001_parent
book: 箴言
chapter: 9
verses: "10"
theme: ['知恵', '畏れ']
token_estimate: 16
---

# 箴言 9章10節

主を恐れることは知恵の本である、聖なる者を知ることは悟りである。