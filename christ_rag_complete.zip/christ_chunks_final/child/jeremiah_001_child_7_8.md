---
id: jeremiah_001_child_7_8
type: child
parent_id: jeremiah_001_parent
book: エレミヤ書
chapter: 17
verses: "7-8"
theme: ['信頼', '実を結ぶ']
token_estimate: 34
---

# エレミヤ書 17章7-8節

おおよそ主にたより、主を頼みとする者はさいわいである。彼は水のほとりに植えた木のように、その根を川のほとりにのばし、暑さが来ても恐れない。