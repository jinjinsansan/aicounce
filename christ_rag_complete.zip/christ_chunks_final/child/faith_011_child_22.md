---
id: faith_011_child_22
type: child
parent_id: faith_011_parent
book: マルコによる福音書
chapter: 11
verses: "22"
theme: ['信仰', '命令']
token_estimate: 10
---

# マルコによる福音書 11章22節

イエスは答えて言われた、「神を信じなさい。