---
id: sermon_001_child_4
type: child
parent_id: sermon_001_parent
book: マタイによる福音書
chapter: 5
verses: "4"
theme: ['悲しみ', '慰め']
token_estimate: 16
---

# マタイによる福音書 5章4節

悲しんでいる人たちは、さいわいである、彼らは慰められるであろう。