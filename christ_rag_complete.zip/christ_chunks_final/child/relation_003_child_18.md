---
id: relation_003_child_18
type: child
parent_id: relation_003_parent
book: ローマ人への手紙
chapter: 12
verses: "18"
theme: ['平和']
token_estimate: 14
---

# ローマ人への手紙 12章18節

あなたがたは、できる限りすべての人と平和に過ごしなさい。