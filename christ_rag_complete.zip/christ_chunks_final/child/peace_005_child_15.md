---
id: peace_005_child_15
type: child
parent_id: peace_005_parent
book: コロサイ人への手紙
chapter: 3
verses: "15"
theme: ['平和', '感謝']
token_estimate: 36
---

# コロサイ人への手紙 3章15節

キリストの平和が、あなたがたの心を支配するようにしなさい。あなたがたが召されて一体となったのは、このためでもある。だから、感謝の心を持ちなさい。