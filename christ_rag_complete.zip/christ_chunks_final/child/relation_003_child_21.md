---
id: relation_003_child_21
type: child
parent_id: relation_003_parent
book: ローマ人への手紙
chapter: 12
verses: "21"
theme: ['善', '悪に勝つ']
token_estimate: 14
---

# ローマ人への手紙 12章21節

悪に負けてはいけない。かえって、善をもって悪に勝ちなさい。