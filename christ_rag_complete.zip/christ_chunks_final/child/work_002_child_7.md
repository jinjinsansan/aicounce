---
id: work_002_child_7
type: child
parent_id: work_002_parent
book: 伝道の書
chapter: 3
verses: "7"
theme: ['言葉の時']
token_estimate: 8
---

# 伝道の書 3章7節

黙るに時があり、語るに時がある。