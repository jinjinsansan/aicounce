---
id: words_003_child_29
type: child
parent_id: words_003_parent
book: エペソ人への手紙
chapter: 4
verses: "29"
theme: ['言葉', '建て上げる']
token_estimate: 38
---

# エペソ人への手紙 4章29節

悪い言葉をいっさい、あなたがたの口から出してはいけない。必要があれば、人の徳を高めるのに役立つような言葉を語って、聞いている者の益になるようにしなさい。