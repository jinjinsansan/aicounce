---
id: sermon_001_child_6
type: child
parent_id: sermon_001_parent
book: マタイによる福音書
chapter: 5
verses: "6"
theme: ['義', '渇き']
token_estimate: 20
---

# マタイによる福音書 5章6節

義に飢えかわいている人たちは、さいわいである、彼らは飽き足りるようになるであろう。