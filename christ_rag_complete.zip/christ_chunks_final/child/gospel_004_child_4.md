---
id: gospel_004_child_4
type: child
parent_id: gospel_004_parent
book: ヨハネによる福音書
chapter: 15
verses: "4"
theme: ['つながる']
token_estimate: 19
---

# ヨハネによる福音書 15章4節

わたしにつながっていなさい。そうすれば、わたしはあなたがたとつながっていよう。