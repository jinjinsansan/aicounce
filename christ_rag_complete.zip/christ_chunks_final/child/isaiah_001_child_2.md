---
id: isaiah_001_child_2
type: child
parent_id: isaiah_001_parent
book: イザヤ書
chapter: 43
verses: "2"
theme: ['神の守り']
token_estimate: 28
---

# イザヤ書 43章2節

あなたが水の中を過ぎるとき、わたしはあなたと共におる。川の中を過ぎるときも、水はあなたの上にあふれることがない。