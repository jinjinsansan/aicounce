---
id: sermon_001_child_3
type: child
parent_id: sermon_001_parent
book: マタイによる福音書
chapter: 5
verses: "3"
theme: ['心の貧しさ', '天国']
token_estimate: 16
---

# マタイによる福音書 5章3節

「こころの貧しい人たちは、さいわいである、天国は彼らのものである。