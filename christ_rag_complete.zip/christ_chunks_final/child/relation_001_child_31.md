---
id: relation_001_child_31
type: child
parent_id: relation_001_parent
book: エペソ人への手紙
chapter: 4
verses: "31"
theme: ['怒り', '悪意']
token_estimate: 20
---

# エペソ人への手紙 4章31節

すべての無慈悲、憤り、怒り、騒ぎ、そしり、また、いっさいの悪意を捨て去りなさい。