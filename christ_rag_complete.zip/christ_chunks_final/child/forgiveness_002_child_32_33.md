---
id: forgiveness_002_child_32_33
type: child
parent_id: forgiveness_002_parent
book: マタイによる福音書
chapter: 18
verses: "32-33"
theme: ['あわれみ', '赦し']
token_estimate: 46
---

# マタイによる福音書 18章32-33節

そこでこの主人は彼を呼びつけて言った、『悪い僕、わたしに願ったからこそ、あの負債を全部ゆるしてやったのだ。わたしがあわれんでやったように、あの仲間をあわれんでやるべきではなかったか』。