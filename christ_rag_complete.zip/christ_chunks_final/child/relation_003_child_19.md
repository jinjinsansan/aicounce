---
id: relation_003_child_19
type: child
parent_id: relation_003_parent
book: ローマ人への手紙
chapter: 12
verses: "19"
theme: ['復讐', '神への委ね']
token_estimate: 17
---

# ローマ人への手紙 12章19節

愛する者たちよ。自分で復讐をしないで、むしろ、神の怒りに任せなさい。