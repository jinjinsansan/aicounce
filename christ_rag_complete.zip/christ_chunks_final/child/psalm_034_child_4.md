---
id: psalm_034_child_4
type: child
parent_id: psalm_034_parent
book: 詩篇
chapter: 34
verses: "4"
theme: ['祈り', '恐れからの解放']
token_estimate: 20
---

# 詩篇 34章4節

わたしが主に求めたとき、主はわたしに答え、すべての恐れからわたしを助け出された。