---
id: sermon_005_child_26_27
type: child
parent_id: sermon_005_parent
book: マタイによる福音書
chapter: 7
verses: "26-27"
theme: ['砂', '不従順']
token_estimate: 40
---

# マタイによる福音書 7章26-27節

また、わたしのこれらの言葉を聞いても行わない者を、砂の上に自分の家を建てた愚かな人に関えよう。雨が降り、洪水が押し寄せ、風が吹いてその家に関打つと、倒れてしまう。