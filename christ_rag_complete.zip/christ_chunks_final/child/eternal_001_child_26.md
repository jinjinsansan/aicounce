---
id: eternal_001_child_26
type: child
parent_id: eternal_001_parent
book: ヨハネによる福音書
chapter: 11
verses: "26"
theme: ['永遠の命']
token_estimate: 14
---

# ヨハネによる福音書 11章26節

また、生きていて、わたしを信じる者は、いつまでも死なない。