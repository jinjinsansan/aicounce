---
id: hope_003_child_3_4
type: child
parent_id: hope_003_parent
book: ローマ人への手紙
chapter: 5
verses: "3-4"
theme: ['苦難', '成長']
token_estimate: 35
---

# ローマ人への手紙 5章3-4節

それだけではなく、患難をも喜んでいる。なぜなら、患難は忍耐を生み出し、忍耐は錬達を生み出し、錬達は希望を生み出すことを、知っているからである。