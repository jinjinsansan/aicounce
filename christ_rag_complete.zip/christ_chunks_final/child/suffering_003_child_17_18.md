---
id: suffering_003_child_17_18
type: child
parent_id: suffering_003_parent
book: コリント人への第二の手紙
chapter: 4
verses: "17-18"
theme: ['永遠', '見えないもの']
token_estimate: 39
---

# コリント人への第二の手紙 4章17-18節

このしばらくの軽い患難は働いて、永遠の重い栄光を、あふれるばかりにわたしたちに得させるからである。わたしたちは、見えるものにではなく、見えないものに目を注ぐ。