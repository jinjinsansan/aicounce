---
id: isaiah_001_child_4
type: child
parent_id: isaiah_001_parent
book: イザヤ書
chapter: 43
verses: "4"
theme: ['価値', '愛']
token_estimate: 18
---

# イザヤ書 43章4節

あなたはわが目に尊く、重んぜられるもの、わたしはあなたを愛するがゆえに。