---
id: psalm_005_child_11_12
type: child
parent_id: psalm_005_parent
book: 詩篇
chapter: 103
verses: "11-12"
theme: ['いつくしみ', '赦し']
token_estimate: 30
---

# 詩篇 103章11-12節

天が地の上に高いように、主のいつくしみは関を関れる者の上に大きい。東が西から関いように、主はわれらの関がを関らせられる。