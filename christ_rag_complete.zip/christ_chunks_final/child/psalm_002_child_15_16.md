---
id: psalm_002_child_15_16
type: child
parent_id: psalm_002_parent
book: 詩篇
chapter: 91
verses: "15-16"
theme: ['応答', '救い']
token_estimate: 42
---

# 詩篇 91章15-16節

彼がわたしを呼ぶとき、わたしは彼に答える。わたしは彼の悩みのときに、共にいて、彼を救い、彼に誉を与えよう。わたしは長寿をもって彼を満ち足らせ、わが救を彼に示すであろう。