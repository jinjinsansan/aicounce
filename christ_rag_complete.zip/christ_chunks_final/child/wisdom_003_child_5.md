---
id: wisdom_003_child_5
type: child
parent_id: wisdom_003_parent
book: 箴言
chapter: 3
verses: "5"
theme: ['信頼', '謙遜']
token_estimate: 14
---

# 箴言 3章5節

心をつくして主に信頼せよ、自分の知識にたよってはならない。