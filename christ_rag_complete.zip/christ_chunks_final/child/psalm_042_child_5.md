---
id: psalm_042_child_5
type: child
parent_id: psalm_042_parent
book: 詩篇
chapter: 42
verses: "5"
theme: ['希望', '落胆への応答']
token_estimate: 35
---

# 詩篇 42章5節

わが魂よ、何ゆえうなだれるのか。何ゆえわたしのうちに思いみだれるのか。神を待ち望め。わたしはなおわが助け、わが神なる主をほめたたえるであろう。