---
id: sermon_001_child_8
type: child
parent_id: sermon_001_parent
book: マタイによる福音書
chapter: 5
verses: "8"
theme: ['清さ', '神を見る']
token_estimate: 14
---

# マタイによる福音書 5章8節

心の清い人たちは、さいわいである、彼らは神を見るであろう。