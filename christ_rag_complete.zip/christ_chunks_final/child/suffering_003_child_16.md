---
id: suffering_003_child_16
type: child
parent_id: suffering_003_parent
book: コリント人への第二の手紙
chapter: 4
verses: "16"
theme: ['希望', '新しさ']
token_estimate: 26
---

# コリント人への第二の手紙 4章16節

だから、わたしたちは落胆しない。たといわたしたちの外なる人は滅びても、内なる人は日ごとに新しくされていく。