---
id: psalm_003_child_10
type: child
parent_id: psalm_003_parent
book: 詩篇
chapter: 46
verses: "10"
theme: ['静まる', '神を知る']
token_estimate: 26
---

# 詩篇 46章10節

「静まって、わたしこそ神であることを知れ。わたしはもろもろの国民のうちにあがめられ、全地にあがめられる」。