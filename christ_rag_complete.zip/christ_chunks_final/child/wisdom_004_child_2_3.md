---
id: wisdom_004_child_2_3
type: child
parent_id: wisdom_004_parent
book: コロサイ人への手紙
chapter: 2
verses: "2-3"
theme: ['キリスト', '知恵']
token_estimate: 26
---

# コロサイ人への手紙 2章2-3節

神の奥義なるキリストを知るに至るためである。キリストのうちには、知恵と知識との宝が、いっさい隠されている。