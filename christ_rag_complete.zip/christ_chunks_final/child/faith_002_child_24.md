---
id: faith_002_child_24
type: child
parent_id: faith_002_parent
book: マルコによる福音書
chapter: 9
verses: "24"
theme: ['信仰', '正直な祈り']
token_estimate: 20
---

# マルコによる福音書 9章24節

その子の父親はすぐ叫んで言った、「信じます。不信仰なわたしを、お助けください」。