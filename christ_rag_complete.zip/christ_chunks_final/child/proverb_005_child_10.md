---
id: proverb_005_child_10
type: child
parent_id: proverb_005_parent
book: 箴言
chapter: 18
verses: "10"
theme: ['神の名', '守り']
token_estimate: 17
---

# 箴言 18章10節

主の名は堅固なやぐらのようだ、正しい者はその中に走りこんで救われる。