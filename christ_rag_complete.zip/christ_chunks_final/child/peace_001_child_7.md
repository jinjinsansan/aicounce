---
id: peace_001_child_7
type: child
parent_id: peace_001_parent
book: ピリピ人への手紙
chapter: 4
verses: "7"
theme: ['平安', '守り']
token_estimate: 31
---

# ピリピ人への手紙 4章7節

そうすれば、人知ではとうてい測り知ることのできない神の平安が、あなたがたの心と思いとを、キリスト・イエスにあって守るであろう。