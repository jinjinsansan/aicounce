---
id: suffering_001_child_7
type: child
parent_id: suffering_001_parent
book: ペテロの第一の手紙
chapter: 5
verses: "7"
theme: ['思い煩い', '神への信頼']
token_estimate: 25
---

# ペテロの第一の手紙 5章7節

神はあなたがたをかえりみていて下さるのであるから、自分の思いわずらいを、いっさい神にゆだねるがよい。