---
id: psalm_130_child_7
type: child
parent_id: psalm_130_parent
book: 詩篇
chapter: 130
verses: "7"
theme: ['待ち望む', '贖い']
token_estimate: 22
---

# 詩篇 130章7節

イスラエルよ、主を待ち望め。主には、いつくしみがあり、また関かなあがないがあるからです。