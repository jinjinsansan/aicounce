---
id: guidance_002_child_4
type: child
parent_id: guidance_002_parent
book: 詩篇
chapter: 37
verses: "4"
theme: ['喜び', '願い']
token_estimate: 14
---

# 詩篇 37章4節

主によって喜びをなせ。主はあなたの心の願いをかなえられる。