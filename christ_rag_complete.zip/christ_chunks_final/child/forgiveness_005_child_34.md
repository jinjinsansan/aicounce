---
id: forgiveness_005_child_34
type: child
parent_id: forgiveness_005_parent
book: ルカによる福音書
chapter: 23
verses: "34"
theme: ['赦し', '祈り']
token_estimate: 27
---

# ルカによる福音書 23章34節

そのとき、イエスは言われた、「父よ、彼らをおゆるしください。彼らは何をしているのか、わからずにいるのです」。