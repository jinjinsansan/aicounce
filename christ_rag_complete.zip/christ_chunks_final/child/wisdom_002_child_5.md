---
id: wisdom_002_child_5
type: child
parent_id: wisdom_002_parent
book: ヤコブの手紙
chapter: 1
verses: "5"
theme: ['知恵', '求める']
token_estimate: 37
---

# ヤコブの手紙 1章5節

あなたがたのうち、知恵に乏しい者があれば、その人は、とがめもせずに惜しみなくすべての人に与える神に、願い求めるがよい。そうすれば、与えられるであろう。