---
id: faith_013_child_17
type: child
parent_id: faith_013_parent
book: ヤコブの手紙
chapter: 2
verses: "17"
theme: ['信仰', '行い']
token_estimate: 17
---

# ヤコブの手紙 2章17節

それと同様に、信仰も行いを伴わなければ、それだけでは死んだものである。