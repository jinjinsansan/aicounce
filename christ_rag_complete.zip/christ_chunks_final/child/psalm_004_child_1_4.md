---
id: psalm_004_child_1_4
type: child
parent_id: psalm_004_parent
book: 詩篇
chapter: 139
verses: "1-4"
theme: ['全知', '知られている']
token_estimate: 32
---

# 詩篇 139章1-4節

主よ、あなたはわたしを調べ、わたしを知りつくされました。あなたはわがすわるをも、立つをも知り、遠くからわが思いをわきまえられます。