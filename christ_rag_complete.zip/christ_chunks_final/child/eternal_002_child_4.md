---
id: eternal_002_child_4
type: child
parent_id: eternal_002_parent
book: 黙示録
chapter: 21
verses: "4"
theme: ['涙の拭い', '希望']
token_estimate: 31
---

# 黙示録 21章4節

人の目から涙を全くぬぐいとって下さる。もはや、死もなく、悲しみも、叫びも、痛みもない。先のものが、すでに過ぎ去ったからである。