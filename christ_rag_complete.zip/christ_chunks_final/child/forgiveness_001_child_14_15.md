---
id: forgiveness_001_child_14_15
type: child
parent_id: forgiveness_001_parent
book: マタイによる福音書
chapter: 6
verses: "14-15"
theme: ['赦し', '条件']
token_estimate: 51
---

# マタイによる福音書 6章14-15節

もしも、あなたがたが、人々のあやまちをゆるすならば、あなたがたの天の父も、あなたがたをゆるして下さるであろう。もし人をゆるさないならば、あなたがたの父も、あなたがたのあやまちをゆるして下さらないであろう。