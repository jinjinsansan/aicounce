---
id: faith_013_child_18
type: child
parent_id: faith_013_parent
book: ヤコブの手紙
chapter: 2
verses: "18"
theme: ['信仰', '証し']
token_estimate: 27
---

# ヤコブの手紙 2章18節

それなら、行いのないあなたの信仰なるものを見せてほしい。そうしたら、わたしの行いによって信仰を見せてあげよう。