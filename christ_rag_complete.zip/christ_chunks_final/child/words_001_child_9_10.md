---
id: words_001_child_9_10
type: child
parent_id: words_001_parent
book: ヤコブの手紙
chapter: 3
verses: "9-10"
theme: ['言葉', '一貫性']
token_estimate: 49
---

# ヤコブの手紙 3章9-10節

わたしたちは、この舌で父なる主をさんびし、また、その同じ舌で、神にかたどって造られた人間をのろっている。同じ口から、さんびとのろいとが出て来る。わたしの兄弟たちよ。このような事は、あるべきでない。