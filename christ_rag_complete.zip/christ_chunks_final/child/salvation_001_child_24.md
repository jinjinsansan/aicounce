---
id: salvation_001_child_24
type: child
parent_id: salvation_001_parent
book: ローマ人への手紙
chapter: 3
verses: "24"
theme: ['恵み', '義']
token_estimate: 23
---

# ローマ人への手紙 3章24節

彼らは、価なしに、神の恵みにより、キリスト・イエスによるあがないによって義とされるのである。