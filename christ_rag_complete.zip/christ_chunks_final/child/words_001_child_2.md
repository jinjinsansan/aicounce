---
id: words_001_child_2
type: child
parent_id: words_001_parent
book: ヤコブの手紙
chapter: 3
verses: "2"
theme: ['言葉', '自制']
token_estimate: 25
---

# ヤコブの手紙 3章2節

もし、言葉の上であやまちのない人があれば、そういう人は、全身をも制御することのできる完全な人である。