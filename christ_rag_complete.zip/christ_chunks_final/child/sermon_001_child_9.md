---
id: sermon_001_child_9
type: child
parent_id: sermon_001_parent
book: マタイによる福音書
chapter: 5
verses: "9"
theme: ['平和', '神の子']
token_estimate: 18
---

# マタイによる福音書 5章9節

平和をつくり出す人たちは、さいわいである、彼らは神の子と呼ばれるであろう。