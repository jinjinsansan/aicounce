---
id: psalm_130_child_3_4
type: child
parent_id: psalm_130_parent
book: 詩篇
chapter: 130
verses: "3-4"
theme: ['赦し']
token_estimate: 38
---

# 詩篇 130章3-4節

主よ、あなたがもしもろもろの不義に目をとめられるならば、主よ、だれが立ちえましょうか。しかしあなたには、ゆるしがあるので、人に恐れかしこまれるでしょう。