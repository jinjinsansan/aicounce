---
id: salvation_004_child_12
type: child
parent_id: salvation_004_parent
book: 使徒行伝
chapter: 4
verses: "12"
theme: ['救い', 'キリスト']
token_estimate: 28
---

# 使徒行伝 4章12節

この人による以外に救はない。わたしたちを救いうる名は、これを別にしては、天下のだれにも与えられていないからである。