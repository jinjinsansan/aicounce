---
id: forgiveness_004_child_31
type: child
parent_id: forgiveness_004_parent
book: エペソ人への手紙
chapter: 4
verses: "31"
theme: ['悪意', '捨てる']
token_estimate: 20
---

# エペソ人への手紙 4章31節

すべての無慈悲、憤り、怒り、騒ぎ、そしり、また、いっさいの悪意を捨て去りなさい。