---
id: strength_005_child_6
type: child
parent_id: strength_005_parent
book: 申命記
chapter: 31
verses: "6"
theme: ['勇気', '神の臨在']
token_estimate: 43
---

# 申命記 31章6節

あなたがたは強く、かつ勇ましくあれ。彼らを恐れ、おののいてはならない。あなたの神、主があなたと共に行かれるからである。主は決してあなたを離れず、あなたを捨てられないであろう。