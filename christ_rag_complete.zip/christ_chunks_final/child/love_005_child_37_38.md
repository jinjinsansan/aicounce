---
id: love_005_child_37_38
type: child
parent_id: love_005_parent
book: マタイによる福音書
chapter: 22
verses: "37-38"
theme: ['神を愛する', '最大の戒め']
token_estimate: 34
---

# マタイによる福音書 22章37-38節

イエスは言われた、「『心をつくし、精神をつくし、思いをつくして、主なるあなたの神を愛せよ』。これがいちばん大切な、第一のいましめである。