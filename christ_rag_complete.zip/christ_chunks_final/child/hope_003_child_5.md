---
id: hope_003_child_5
type: child
parent_id: hope_003_parent
book: ローマ人への手紙
chapter: 5
verses: "5"
theme: ['希望', '神の愛']
token_estimate: 33
---

# ローマ人への手紙 5章5節

そして、希望は失望に終ることはない。なぜなら、わたしたちに賜わっている聖霊によって、神の愛がわたしたちの心に注がれているからである。