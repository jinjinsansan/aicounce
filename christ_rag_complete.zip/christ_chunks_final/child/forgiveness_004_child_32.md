---
id: forgiveness_004_child_32
type: child
parent_id: forgiveness_004_parent
book: エペソ人への手紙
chapter: 4
verses: "32"
theme: ['赦し', 'あわれみ']
token_estimate: 31
---

# エペソ人への手紙 4章32節

互に情深く、あわれみ深い者となり、神がキリストにあってあなたがたをゆるして下さったように、あなたがたも互にゆるし合いなさい。