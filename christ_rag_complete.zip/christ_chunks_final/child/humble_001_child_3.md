---
id: humble_001_child_3
type: child
parent_id: humble_001_parent
book: ピリピ人への手紙
chapter: 2
verses: "3"
theme: ['謙遜']
token_estimate: 24
---

# ピリピ人への手紙 2章3節

何事も党派心や虚栄からするのでなく、へりくだった心をもって互に人を自分よりすぐれた者としなさい。