---
id: humble_002_child_8
type: child
parent_id: humble_002_parent
book: ヤコブの手紙
chapter: 4
verses: "8"
theme: ['神への近づき']
token_estimate: 17
---

# ヤコブの手紙 4章8節

神に近づきなさい。そうすれば、神はあなたがたに近づいて下さるであろう。