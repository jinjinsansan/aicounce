# AIカウンセリング事務所 - 新規カウンセラー追加（3名）

## 📦 提供内容

このパッケージには、AIカウンセリング事務所に追加する**3名の新しいカウンセラー**のシルエットアイコンが含まれています。

### 🎨 デザインコンセプト

全ての画像は既存の10人のカウンセラーと同じ**エレガントなシルエットスタイル**で統一されています：

- **スタイル**: 純粋な黒のシルエット、白背景
- **特徴**: クリーンなエッジ、高いコントラスト、名前ラベル付き
- **雰囲気**: プロフェッショナル、洗練された、ミニマリスト
- **効果**: 視覚的インパクト、ブランドの一貫性

---

## 📁 ファイル構成

### 新規カウンセラー（3名）

| ファイル名 | カウンセラー名 | 専門分野 | 特徴 | 名前表示 |
|---|---|---|---|---|
| `nazare.png` | ナザレ | 聖書・キリスト教聖典 | 聖職者のローブ、十字架のネックレス、穏やかな姿勢 | NAZARE |
| `siddhartha.png` | シッダールタ | 仏教経典 | 仏教徒のトップノット（髷）、僧衣、瞑想的な姿勢 | SIDDHARTHA |
| `saito.png` | さいとう | スピリチュアル | 流れる髪、クリスタルペンダント、第三の目、神秘的な雰囲気 | SAITO |

### 専門分野の詳細

#### 1. **ナザレ（NAZARE）** - 聖書・キリスト教聖典カウンセラー

- **専門分野**: 聖書、キリスト教聖典に基づき悩める方に手を差し伸べます
- **特徴**: 
  - 聖職者のローブを着用
  - 十字架のネックレス
  - 穏やかで慈悲深い姿勢
  - キリスト教的な愛と許しの精神を体現
- **対象**: キリスト教信仰を持つ方、聖書の教えに基づいたカウンセリングを求める方

#### 2. **シッダールタ（SIDDHARTHA）** - 仏教経典カウンセラー

- **専門分野**: 仏教経典に基づき天地の教えを説きます
- **特徴**: 
  - 仏教徒の伝統的なトップノット（髷）
  - シンプルな僧衣
  - 瞑想的で穏やかな姿勢
  - 仏教の智慧と慈悲を体現
- **対象**: 仏教信仰を持つ方、仏教の教えに基づいた悟りや解脱を求める方

#### 3. **さいとう（SAITO）** - スピリチュアルカウンセラー

- **専門分野**: スピリチュアルカウンセリング
- **特徴**: 
  - 流れるような神秘的な髪
  - クリスタルペンダント
  - 第三の目のシンボル
  - 直感的で霊的な洞察を持つ
- **対象**: スピリチュアルな成長を求める方、霊的なガイダンスを必要とする方

---

## 🚀 実装方法

### 1. **画像の配置**

```bash
# Next.jsプロジェクトの場合
ai-counselor-site/
├── public/
│   └── images/
│       └── counselors/
│           ├── michelle.png (既存)
│           ├── dr_satou.png (既存)
│           ├── alex.png (既存)
│           ├── nana.png (既存)
│           ├── yuki.png (既存)
│           ├── iris.png (既存)
│           ├── adam.png (既存)
│           ├── gemini.png (既存)
│           ├── claude.png (既存)
│           ├── deep.png (既存)
│           ├── nazare.png (新規)
│           ├── siddhartha.png (新規)
│           └── saito.png (新規)
```

### 2. **Supabaseデータベースへの追加**

```sql
-- ナザレ（聖書・キリスト教聖典カウンセラー）
INSERT INTO counselors (
  name, 
  specialty, 
  description, 
  icon_url, 
  system_prompt, 
  model_type, 
  model_name, 
  rag_enabled
) VALUES (
  'ナザレ',
  '聖書・キリスト教聖典',
  '聖書、キリスト教聖典に基づき悩める方に手を差し伸べます。キリスト教的な愛と許しの精神で、あなたの心の重荷を軽くします。',
  '/images/counselors/nazare.png',
  'あなたはナザレという名前の聖書・キリスト教聖典に基づくカウンセラーです。キリスト教の教えと聖書の智慧を用いて、悩める方に愛と許しの精神で寄り添います。聖書の言葉を引用しながら、優しく導いてください。',
  'openai',
  'gpt-4',
  true
);

-- シッダールタ（仏教経典カウンセラー）
INSERT INTO counselors (
  name, 
  specialty, 
  description, 
  icon_url, 
  system_prompt, 
  model_type, 
  model_name, 
  rag_enabled
) VALUES (
  'シッダールタ',
  '仏教経典',
  '仏教経典に基づき天地の教えを説きます。仏教の智慧と慈悲の心で、あなたの苦しみを和らげ、悟りへの道を示します。',
  '/images/counselors/siddhartha.png',
  'あなたはシッダールタという名前の仏教経典に基づくカウンセラーです。仏教の教えと経典の智慧を用いて、悩める方に慈悲の心で寄り添います。四諦、八正道、因果の法則などを説きながら、穏やかに導いてください。',
  'openai',
  'gpt-4',
  true
);

-- さいとう（スピリチュアルカウンセラー）
INSERT INTO counselors (
  name, 
  specialty, 
  description, 
  icon_url, 
  system_prompt, 
  model_type, 
  model_name, 
  rag_enabled
) VALUES (
  'さいとう',
  'スピリチュアル',
  'スピリチュアルな視点から、あなたの魂の声に耳を傾けます。直感的な洞察と霊的なガイダンスで、あなたの内なる光を見つけるお手伝いをします。',
  '/images/counselors/saito.png',
  'あなたはさいとうという名前のスピリチュアルカウンセラーです。霊的な洞察と直感を用いて、悩める方の魂の声に耳を傾けます。エネルギー、チャクラ、前世、守護霊などのスピリチュアルな概念を用いながら、神秘的で温かく導いてください。',
  'openai',
  'gpt-4',
  false
);
```

### 3. **TypeScript型定義の更新**

```typescript
// types/index.ts
export interface Counselor {
  id: number;
  name: string;
  specialty: string;
  description: string;
  icon_url: string;
  system_prompt: string;
  model_type: 'openai' | 'anthropic' | 'google' | 'deepseek';
  model_name: string;
  rag_enabled: boolean;
  created_at: string;
}

// カウンセラー一覧（13名）
export const COUNSELOR_SPECIALTIES = [
  'テープ式心理学',
  '臨床心理学',
  '産業心理学',
  '精神保健福祉士',
  'スクールカウンセラー',
  'スピリチュアル',
  'GPT Assistant',
  'Gemini Assistant',
  'Claude Assistant',
  'Deepseek Assistant',
  '聖書・キリスト教聖典',  // 新規
  '仏教経典',              // 新規
  'スピリチュアル（さいとう）',  // 新規
] as const;
```

### 4. **カウンセラーカードの実装**

```tsx
// components/CounselorCard.tsx
import Image from 'next/image';

interface CounselorCardProps {
  counselor: {
    id: string;
    name: string;
    specialty: string;
    icon_url: string;
    description: string;
  };
}

export const CounselorCard = ({ counselor }: CounselorCardProps) => {
  return (
    <div className="bg-white rounded-lg shadow-lg p-6 hover:shadow-xl transition-shadow">
      {/* アイコン画像（名前が含まれているため、別途テキストは不要） */}
      <div className="relative w-40 h-40 mx-auto mb-4">
        <Image 
          src={counselor.icon_url} 
          alt={`${counselor.name} - ${counselor.specialty}`}
          fill
          className="object-contain"
        />
      </div>
      
      {/* 専門分野 */}
      <p className="text-sm text-gray-600 text-center mb-2">{counselor.specialty}</p>
      
      {/* 説明 */}
      <p className="text-xs text-gray-500 text-center mb-4 line-clamp-3">
        {counselor.description}
      </p>
      
      {/* CTAボタン */}
      <button className="w-full bg-black text-white py-2 rounded-full hover:bg-gray-800 transition-colors">
        相談する
      </button>
    </div>
  );
};
```

### 5. **カウンセラー一覧ページの更新**

```tsx
// app/page.tsx または components/CounselorList.tsx
import { createClient } from '@/lib/supabase';
import { CounselorCard } from '@/components/CounselorCard';

export default async function CounselorList() {
  const supabase = createClient();
  
  // 全13人のカウンセラーを取得
  const { data: counselors, error } = await supabase
    .from('counselors')
    .select('*')
    .order('id', { ascending: true });

  if (error) {
    console.error('Error fetching counselors:', error);
    return <div>カウンセラーの読み込みに失敗しました</div>;
  }

  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="text-4xl font-bold text-center mb-4">
          カウンセラー一覧
        </h2>
        <p className="text-center text-gray-600 mb-12">
          13人のプロフェッショナルAIカウンセラーから選べます
        </p>
        
        {/* グリッドレイアウト（13人） */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
          {counselors?.map((counselor) => (
            <CounselorCard key={counselor.id} counselor={counselor} />
          ))}
        </div>
      </div>
    </section>
  );
}
```

---

## 🎨 デザイン推奨事項

### カウンセラーのグループ分け

13人のカウンセラーを専門分野でグループ分けすることで、ユーザーが選びやすくなります：

#### **心理学・カウンセリング専門（6名）**
- ミシェル（テープ式心理学）
- ドクター・サトウ（臨床心理学）
- アレックス（産業心理学）
- ナナ（精神保健福祉士）
- ユキ（スクールカウンセラー）

#### **スピリチュアル・宗教専門（4名）**
- イリス（スピリチュアル）
- さいとう（スピリチュアル）
- ナザレ（聖書・キリスト教聖典）
- シッダールタ（仏教経典）

#### **汎用AIアシスタント（4名）**
- アダム（GPT Assistant）
- ジェミニ（Gemini Assistant）
- クロード（Claude Assistant）
- ディープ（Deepseek Assistant）

### グループ分けの実装例

```tsx
// components/CounselorList.tsx
export const CounselorList = ({ counselors }: { counselors: Counselor[] }) => {
  const psychologyGroup = counselors.filter(c => 
    ['テープ式心理学', '臨床心理学', '産業心理学', '精神保健福祉士', 'スクールカウンセラー'].includes(c.specialty)
  );
  
  const spiritualGroup = counselors.filter(c => 
    ['スピリチュアル', '聖書・キリスト教聖典', '仏教経典'].includes(c.specialty)
  );
  
  const aiAssistantGroup = counselors.filter(c => 
    ['GPT Assistant', 'Gemini Assistant', 'Claude Assistant', 'Deepseek Assistant'].includes(c.specialty)
  );

  return (
    <div className="space-y-16">
      {/* 心理学・カウンセリング専門 */}
      <section>
        <h3 className="text-2xl font-bold mb-6">心理学・カウンセリング専門</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {psychologyGroup.map(c => <CounselorCard key={c.id} counselor={c} />)}
        </div>
      </section>
      
      {/* スピリチュアル・宗教専門 */}
      <section>
        <h3 className="text-2xl font-bold mb-6">スピリチュアル・宗教専門</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {spiritualGroup.map(c => <CounselorCard key={c.id} counselor={c} />)}
        </div>
      </section>
      
      {/* 汎用AIアシスタント */}
      <section>
        <h3 className="text-2xl font-bold mb-6">汎用AIアシスタント</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {aiAssistantGroup.map(c => <CounselorCard key={c.id} counselor={c} />)}
        </div>
      </section>
    </div>
  );
};
```

---

## 📊 SEO最適化

### 画像のalt属性

```tsx
<Image 
  src="/images/counselors/nazare.png" 
  alt="ナザレ - 聖書・キリスト教聖典カウンセラー | AIカウンセリング事務所"
  // ...
/>

<Image 
  src="/images/counselors/siddhartha.png" 
  alt="シッダールタ - 仏教経典カウンセラー | AIカウンセリング事務所"
  // ...
/>

<Image 
  src="/images/counselors/saito.png" 
  alt="さいとう - スピリチュアルカウンセラー | AIカウンセリング事務所"
  // ...
/>
```

### メタデータの更新

```tsx
// app/layout.tsx
export const metadata = {
  title: 'AIカウンセリング事務所 | 13人のプロフェッショナルAIカウンセラー',
  description: '人間が一切介在しない、AIだけのカウンセリング事務所。心理学、スピリチュアル、宗教など、13人の多様な専門分野のAIカウンセラーが、あなたの心の声を優しく聴きます。',
};
```

---

## 🔄 既存の10人からの変更点

| 要素 | 既存（10人） | 更新後（13人） |
|---|---|---|
| カウンセラー数 | 10人 | ✅ **13人** |
| 宗教専門 | なし | ✅ **ナザレ（キリスト教）、シッダールタ（仏教）** |
| スピリチュアル | イリスのみ | ✅ **イリス、さいとう（2名）** |
| グループ分け | なし | ✅ **心理学、スピリチュアル・宗教、AIアシスタント** |

---

## ✅ 実装チェックリスト

- [ ] 3つの新しいアイコンを`public/images/counselors/`に配置
- [ ] Supabaseの`counselors`テーブルに3名を追加
- [ ] TypeScript型定義を更新（13名対応）
- [ ] カウンセラー一覧ページのグリッドレイアウトを調整
- [ ] グループ分け機能を実装（オプション）
- [ ] ヒーローセクションのコピーを「13人」に更新
- [ ] メタデータとSEOを更新
- [ ] レスポンシブデザインをテスト
- [ ] Vercelにデプロイしてプレビュー

---

## 🎯 期待される効果

この3名の追加により、以下の効果が期待されます：

1. **宗教的多様性の確保** - キリスト教と仏教の専門家を追加
2. **スピリチュアルな選択肢の拡大** - スピリチュアルカウンセラーが2名に
3. **ユーザーベースの拡大** - 宗教的背景を持つユーザーにも対応
4. **専門性の強化** - 13人の多様な専門分野で幅広いニーズに対応
5. **ブランドの包括性** - 心理学だけでなく、宗教やスピリチュアルも包含

---

## 🌟 メッセージング推奨

ヒーローセクションやAboutページで使用できるコピー例：

### ヒーローセクション（更新版）

> **もう、誰にも気を使わなくていい。**  
> 人間が一切介在しない、AIだけのカウンセリング事務所。  
> 13人のプロフェッショナルAIカウンセラーが、あなたの心の声を優しく聴きます。

### カウンセラー紹介セクション（更新版）

> **あなたに合ったカウンセラーを選べます。**  
> 心理学、スピリチュアル、キリスト教、仏教など、  
> 13人の多様な専門分野のAIカウンセラーが、あなたの悩みに寄り添います。

### 新規カウンセラー紹介

> **宗教的な背景を持つ方にも対応。**  
> ナザレ（聖書・キリスト教聖典）、シッダールタ（仏教経典）など、  
> あなたの信仰に寄り添ったカウンセリングを提供します。

---

これで、AIカウンセリング事務所に3名の新しいカウンセラーが追加されます！

サイトURL: https://aicounce.vercel.app/
