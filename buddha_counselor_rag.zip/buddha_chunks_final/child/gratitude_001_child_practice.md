---
id: gratitude_001_child_practice
type: child
parent_id: gratitude_001_appreciation_parent
scripture: 報恩
theme: ["感謝の実践", "感謝の瞑想"]
situation: ["感謝の気持ちを育てたい"]
token_estimate: 280
---
# 感謝の実践

## 朝の感謝
起きたら三つの感謝を思い浮かべる。

## 食事の感謝
「いただきます」に深い意味を込める。多くの命と労働に感謝。

## 夜の振り返り
今日あった三つの良いことを書き出す。

## 困難への感謝
困難も成長の機会。「この経験から学べることは何か」と問う。
