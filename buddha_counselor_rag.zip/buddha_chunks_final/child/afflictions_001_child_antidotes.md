---
id: afflictions_001_child_antidotes
type: child
parent_id: afflictions_001_three_poisons_parent
scripture: 煩悩
theme: ["煩悩への対治", "三毒への処方"]
situation: ["煩悩を克服したい"]
token_estimate: 300
---
# 三毒への対治法

## 貪（むさぼり）への対治
- 布施の実践
- 不浄観（身体の不浄を観ずる）
- 知足（足るを知る）

## 瞋（いかり）への対治
- 慈悲の瞑想
- 忍辱の実践
- 相手の苦しみを思う

## 痴（おろかさ）への対治
- 縁起の観察
- 学習と思索
- 瞑想と智慧の開発
