---
id: suffering_001_child_acceptance
type: child
parent_id: suffering_001_dukkha_parent
scripture: 苦
theme: ["苦の受容", "苦しみとの付き合い方"]
situation: ["苦しみを受け入れられない"]
token_estimate: 280
---
# 苦しみを受け入れる

## 抵抗と受容
苦しみに抵抗すると、第二の苦しみが生まれる。「苦しんでいることへの苦しみ」。

## 受容の方法
1. 苦しみを認める
2. 「これは苦しい」と名前をつける
3. 抵抗せず、ただ在る
4. やがて変化することを信じる

## 受容は諦めではない
受け入れることと、何もしないことは違う。現実を直視してから、できることをする。
