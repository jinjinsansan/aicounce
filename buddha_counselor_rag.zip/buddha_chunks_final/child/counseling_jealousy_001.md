---
id: counseling_jealousy_001
type: child
parent_id: four_immeasurables_003_mudita_parent
scripture: 応用
theme: ["嫉妬", "羨望"]
situation: ["嫉妬してしまう", "人の成功を喜べない"]
token_estimate: 280
---
# 嫉妬への仏教的アプローチ

## 嫉妬の理解
嫉妬は「自分には足りない」という思いから生まれる。

## 嫉妬を喜びに変える
1. 嫉妬に気づく
2. 「この人にも苦しみがある」と思う
3. 「この人の幸せを喜ぶ」と念じる
4. 自分の持っているものに感謝

## 随喜功徳
他者の善行や幸福を喜ぶと、自分も功徳を積める。
