---
id: six_paramitas_003_child_types
type: child
parent_id: six_paramitas_003_kshanti_parent
scripture: 六波羅蜜
theme: ["忍辱の種類", "忍耐の修行"]
situation: ["忍耐を身につけたい"]
token_estimate: 280
---
# 三種の忍辱

## 忍辱の種類
1. **耐怨害忍**：他者からの害を耐え忍ぶ
2. **安受苦忍**：苦難を安らかに受け入れる
3. **諦察法忍**：真理を受け入れる忍耐

## 実践のコツ
怒りが起きたら、まず深呼吸。「この感情は無常である」と観じ、反応を遅らせる。
