---
id: four_noble_truths_002_child_craving
type: child
parent_id: four_noble_truths_002_origin_parent
scripture: 四諦
theme: ["渇愛の種類", "苦の原因"]
situation: ["なぜ苦しむのか深く理解したい"]
token_estimate: 280
---
# 渇愛の三種

## 苦の原因となる渇愛
1. **欲愛**：感覚的快楽への渇望
2. **有愛**：存在・永続への渇望
3. **無有愛**：消滅・破壊への渇望

## 解説
すべての苦しみの根源は「もっと欲しい」「永遠に続いて欲しい」「消えてしまいたい」という渇望です。
