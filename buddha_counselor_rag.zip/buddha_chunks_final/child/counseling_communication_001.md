---
id: counseling_communication_001
type: child
parent_id: speech_001_right_words_parent
scripture: 応用
theme: ["コミュニケーション", "対話"]
situation: ["うまく伝えられない", "誤解される"]
token_estimate: 280
---
# コミュニケーションへの仏教的アプローチ

## 正語の実践
1. **真実**：本当のことを言う
2. **優しさ**：相手を傷つけない
3. **必要性**：本当に必要か考える
4. **タイミング**：適切な時に話す

## 聴くことの大切さ
話す前に、まず聴く。相手を理解しようとする姿勢。

## 沈黙の力
言わないことも伝える。時に沈黙が最善。
