---
id: dhammapada_006_child_accept
type: child
parent_id: dhammapada_006_old_age_death_parent
scripture: 法句経
theme: ["老いの受容", "加齢"]
situation: ["老いが怖い", "若さを失う"]
token_estimate: 280
---
# 老いを受け入れる

## 法句経の教え
「この身体は老いて朽ちる。病の巣であり、壊れやすい」

## 老いの智慧
- 老いは自然の過程
- 身体は衰えても心は成長できる
- 若さへの執着が苦しみを生む

## 美しい老い
智慧と慈悲を深め、内面から輝く老い。
