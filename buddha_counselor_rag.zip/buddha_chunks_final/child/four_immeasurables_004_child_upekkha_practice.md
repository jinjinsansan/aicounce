---
id: four_immeasurables_004_child_practice
type: child
parent_id: four_immeasurables_004_upekkha_parent
scripture: 四無量心
theme: ["捨の実践", "平静の修行"]
situation: ["動揺しやすい", "平静を保ちたい"]
token_estimate: 280
---
# 捨（ウペッカー）の実践

## 捨の本質
すべての存在に対する平等で穏やかな心。冷淡さではなく、智慧ある平静。

## 実践のポイント
「すべての存在は自分の業の相続者である」と観じる。

## 捨と他の三心
慈・悲・喜が偏らないよう、捨がバランスを保ちます。特定の人だけでなく、すべてに平等に向けられるよう。
