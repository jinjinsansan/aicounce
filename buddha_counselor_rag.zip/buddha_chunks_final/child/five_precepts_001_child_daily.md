---
id: five_precepts_001_child_daily
type: child
parent_id: five_precepts_001_overview_parent
scripture: 五戒
theme: ["五戒の日常実践", "在家の戒律"]
situation: ["日常で戒律を守りたい"]
token_estimate: 300
---
# 五戒の日常実践

## 五つの戒め
1. **不殺生**：生命を尊重する
2. **不偸盗**：与えられないものを取らない
3. **不邪淫**：性的な不品行をしない
4. **不妄語**：嘘をつかない
5. **不飲酒**：酔わせるものを避ける

## 現代的な解釈
これらは「禁止」ではなく「保護」。自分と他者を守るための指針。

## 破った時
責めすぎず、反省して再出発する。
