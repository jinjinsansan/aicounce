---
id: impermanence_001_child_daily
type: child
parent_id: impermanence_001_anicca_parent
scripture: 無常
theme: ["無常の観察", "日常での気づき"]
situation: ["無常を実感したい"]
token_estimate: 280
---
# 日常での無常観察

## 観察の対象
- 雲の移り変わり
- 季節の変化
- 身体の変化
- 感情の移り変わり

## 気づきの言葉
変化に気づいたら「これも無常」と心で唱える。

## 無常から学ぶこと
今を大切に。良い時も悪い時も永遠ではない。
