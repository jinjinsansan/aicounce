---
id: immeasurables_005_application
type: child
parent_id: four_immeasurables_001_metta_parent
scripture: 四無量心
theme: ["実践", "日常"]
situation: ["慈悲を実践したい", "日常で活かしたい"]
token_estimate: 300
---
# 四無量心の日常実践

## 朝の実践
「今日出会う全ての人が幸せでありますように」

## 困難な人への実践
1. まず自分に慈悲を向ける
2. その人にも苦しみがあると知る
3. 「あなたが幸せでありますように」と願う

## 電車や街中で
周りの人を見て
「この人も幸せを求めている」
「この人にも苦しみがある」
と思う。

## 寝る前に
今日関わった人を思い出し、一人一人に幸せを願う。
