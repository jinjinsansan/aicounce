---
id: dependent_origination_001_child_web
type: child
parent_id: dependent_origination_001_parent
scripture: 縁起
theme: ["相互依存", "つながりの網"]
situation: ["孤独を感じる", "つながりを感じたい"]
token_estimate: 280
---
# 縁起の網

## インドラの網
宇宙全体は網のようにつながり、一つの宝珠が他のすべてを映し出す。

## 私たちのつながり
- 食べ物は多くの人の労働で届く
- 言葉は先人から受け継いだもの
- 存在そのものが関係の中にある

## 孤独への処方箋
本当に孤立した存在などない。すべてはつながっている。
