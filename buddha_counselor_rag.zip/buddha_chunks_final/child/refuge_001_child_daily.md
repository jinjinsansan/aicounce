---
id: refuge_001_child_daily
type: child
parent_id: refuge_001_taking_refuge_parent
scripture: 帰依
theme: ["日常の帰依", "三帰依の実践"]
situation: ["帰依を日常に活かしたい"]
token_estimate: 280
---
# 日常での三帰依

## 朝の実践
起床時に三帰依を唱える。
「仏に帰依し奉る」
「法に帰依し奉る」
「僧に帰依し奉る」

## 困った時の実践
迷った時、「仏ならどうするか」と問う。

## 夜の実践
一日を振り返り、三宝への感謝を捧げる。
