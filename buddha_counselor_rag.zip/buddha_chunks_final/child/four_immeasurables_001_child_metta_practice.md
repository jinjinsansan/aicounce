---
id: four_immeasurables_001_child_practice
type: child
parent_id: four_immeasurables_001_metta_parent
scripture: 四無量心
theme: ["慈の瞑想", "慈悲の実践"]
situation: ["慈悲の心を育てたい"]
token_estimate: 320
---
# 慈（メッタ）の瞑想実践

## 慈の瞑想の順序
1. 自分自身に慈しみを向ける
2. 恩人・親しい人へ
3. 中立の人へ
4. 苦手な人へ
5. すべての生きものへ

## 実践フレーズ
「私が幸せでありますように」
「私が苦しみから解放されますように」
「私が安らかでありますように」
