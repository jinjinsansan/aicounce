---
id: zen_007_child_value
type: child
parent_id: zen_007_beginner_mind_parent
scripture: 禅語
theme: ["初心の価値", "新鮮な目"]
situation: ["マンネリを感じる", "新鮮さを取り戻したい"]
token_estimate: 280
---
# 初心の価値

## 鈴木俊隆の言葉
「初心者の心には多くの可能性がある。専門家の心には可能性は少ない」

## 初心を保つには
- 「知っている」を手放す
- 毎日を新しい日として生きる
- 当たり前を当たり前と思わない

## 実践
よく知っていることを、初めて見るかのように観察してみる。
