---
id: ten_virtues_001_child_deep
type: child
parent_id: ten_virtues_001_no_killing_parent
scripture: 十善戒
theme: ["不殺生の深義", "生命の尊重"]
situation: ["命の大切さを理解したい"]
token_estimate: 280
---
# 不殺生の深い意味

## 積極的な側面
不殺生は「殺さない」だけでなく「生かす」こと。
- 生命を守り育てる
- 害から守る
- 恐れを与えない

## 現代での実践
- 虫も無闘に殺さない
- 環境を守る
- 言葉で人の心を殺さない
