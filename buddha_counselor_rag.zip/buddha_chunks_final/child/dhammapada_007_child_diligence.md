---
id: dhammapada_007_child_diligence
type: child
parent_id: dhammapada_007_vigilance_parent
scripture: 法句経
theme: ["精進", "怠惰を克服"]
situation: ["怠けてしまう", "続かない"]
token_estimate: 280
---
# 不放逸の実践

## 法句経の教え
「不放逸は不死の道、放逸は死の道」

## 精進の実践
1. 毎日少しでも実践
2. 完璧を求めない
3. 仲間と励まし合う
4. 小さな成功を喜ぶ

## 怠惰への対治
「人生は短い」と思い出す。今日を大切に。
