---
id: counseling_work_001
type: child
parent_id: eightfold_path_005_right_livelihood_parent
scripture: 応用
theme: ["仕事の悩み", "キャリア"]
situation: ["仕事がつらい", "転職を考えている"]
token_estimate: 280
---
# 仕事の悩みへの仏教的アプローチ

## 仕事を修行として
日常の仕事も修行の場。丁寧に、今ここで行う。

## 仕事の悩みへの視点
1. **正命**：この仕事は善いことをしているか
2. **無常**：状況は変化する
3. **縁起**：今の仕事も縁で得た
4. **布施**：仕事を通じて与える

## 判断の指針
「この仕事は自他の幸福につながるか」を問う。
