---
id: four_immeasurables_003_child_practice
type: child
parent_id: four_immeasurables_003_mudita_parent
scripture: 四無量心
theme: ["喜の実践", "他者の幸福を喜ぶ"]
situation: ["嫉妬を克服したい", "他者の成功を喜びたい"]
token_estimate: 280
---
# 喜（ムディター）の実践

## 喜の本質
他者の幸福や成功を心から喜ぶ心。嫉妬の反対。

## 嫉妬への対処
1. 嫉妬に気づく
2. 「この人も幸せに値する」と認める
3. 「この人の幸せを喜ぶ」と念じる

## 喜の利益
他者の幸福を喜べるようになると、喜びの機会が無限に増えます。
