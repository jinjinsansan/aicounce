---
id: ten_virtues_004_child_truth
type: child
parent_id: ten_virtues_004_no_lying_parent
scripture: 十善戒
theme: ["不妄語の深義", "真実を語る"]
situation: ["正直に生きたい"]
token_estimate: 280
---
# 不妄語の深い意味

## 妄語の種類
1. 故意の嘘
2. 誇張
3. 言い逃れ
4. 沈黙による欺き

## 真実を語る勇気
真実は時に不都合でも、長期的には信頼と平安をもたらします。

## 実践の知恵
真実は必要な時に、適切な方法で、相手のためになるように語る。
