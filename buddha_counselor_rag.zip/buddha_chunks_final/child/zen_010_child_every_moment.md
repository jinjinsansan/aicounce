---
id: zen_010_child_moment
type: child
parent_id: zen_010_every_day_good_day_parent
scripture: 禅語
theme: ["一期一会", "今を生きる"]
situation: ["今を大切にしたい"]
token_estimate: 280
---
# 日日是好日の実践

## 雲門禅師の言葉
「日日是好日」—毎日が良い日である。

## 深い意味
晴れても雨でも、楽しくても苦しくても、その日をそのまま受け入れる。

## 一期一会
今この瞬間は二度と来ない。だからこそ、すべての出会いと瞬間を大切に。

## 実践
朝起きたら「今日も良い日だ」と心で唱える。
