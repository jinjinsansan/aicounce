---
id: pure_land_002_child_practice
type: child
parent_id: pure_land_002_nembutsu_parent
scripture: 浄土経典
theme: ["念仏の実践", "南無阿弥陀仏"]
situation: ["念仏を実践したい"]
token_estimate: 280
---
# 念仏の実践

## 念仏の唱え方
「南無阿弥陀仏」（なむあみだぶつ）
「南無」＝帰依します
「阿弥陀仏」＝無量の光と命の仏

## いつ唱えるか
- 毎朝毎晩
- 苦しい時、不安な時
- 感謝の時
- いつでも、どこでも

## 念仏の効果
心が落ち着き、安心が生まれる。仏と共にあるという実感。
