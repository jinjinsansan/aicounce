---
id: peace_001_child_cultivation
type: child
parent_id: peace_001_inner_peace_parent
scripture: 寂静
theme: ["平安の育て方", "内なる静けさ"]
situation: ["心の平安を得たい"]
token_estimate: 280
---
# 内なる平安の育て方

## 平安を乱すもの
- 過去への後悔
- 未来への不安
- 比較と競争
- 執着と渇望

## 平安を育てるもの
- 今ここへの集中
- 感謝の心
- 手放し
- 慈悲の実践

## 毎日の実践
朝5分の静坐。何もしない、ただ在る時間を持つ。
