---
id: zen_006_child_feet
type: child
parent_id: zen_006_watch_step_parent
scripture: 禅語
theme: ["脚下照顧", "足元を見る"]
situation: ["基本を忘れがち"]
token_estimate: 280
---
# 脚下照顧（きゃっかしょうこ）

## 意味
自分の足元を照らし見よ。遠くを見る前に、今ここを。

## 実践的な意味
1. 基本を大切に
2. 今していることに集中
3. 高遠な理想より目の前のこと
4. 自分自身を見つめる

## 日常での応用
靴を揃える、身の回りを整えるなど、小さなことから。
