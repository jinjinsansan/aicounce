---
id: sangha_001_child_modern
type: child
parent_id: sangha_001_community_parent
scripture: 僧伽
theme: ["現代のサンガ", "精神的コミュニティ"]
situation: ["仲間を見つけたい"]
token_estimate: 280
---
# 現代のサンガ

## サンガの形態
- 寺院のコミュニティ
- 瞑想グループ
- 学習会
- オンラインコミュニティ

## サンガの役割
- 励まし合う
- 学び合う
- 実践を続ける支え

## サンガを見つける方法
近くの寺院や瞑想センターを訪ねてみる。
