---
id: kannon_001_child_calling
type: child
parent_id: kannon_sutra_001_parent
scripture: 観音経
theme: ["観音を呼ぶ", "名号の力"]
situation: ["危機的状況", "助けを求める"]
token_estimate: 280
---
# 観音の名を呼ぶ

## 観音経の教え
「一心に観世音菩薩の名を称えれば、苦しみから免れる」

## 実践
「南無観世音菩薩」と唱える。

## 七難からの救い
1. 火難 2. 水難 3. 羅刹難 4. 刀杖難
5. 鬼難 6. 枷鎖難 7. 怨賊難

## 現代での意味
物理的な災難だけでなく、心の苦しみからも救ってくださる。
