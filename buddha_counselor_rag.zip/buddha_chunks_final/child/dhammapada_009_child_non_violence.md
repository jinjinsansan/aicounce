---
id: dhammapada_009_child_non
type: child
parent_id: dhammapada_009_punishment_parent
scripture: 法句経
theme: ["非暴力", "報復しない"]
situation: ["仕返ししたい", "暴力に頼りたくなる"]
token_estimate: 280
---
# 非暴力の道

## 法句経の教え
「すべての者は刀杖を恐れ、すべての者は死を恐れる。自己と比較して、殺すな、殺させるな」

## 非暴力の智慧
暴力は暴力を生む。連鎖を断つのは非暴力のみ。

## 実践
言葉の暴力にも気をつける。SNSでの攻撃、陰口も暴力。
