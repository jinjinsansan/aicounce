---
id: patience_001_child_daily
type: child
parent_id: patience_001_khanti_parent
scripture: 忍辱
theme: ["日常の忍耐", "小さな実践"]
situation: ["日常でイライラする"]
token_estimate: 280
---
# 日常での忍耐の実践

## 小さな機会
- 渋滞や行列
- 遅いインターネット
- 人の失敗

## 実践のコツ
1. イライラに気づく
2. 深呼吸を3回
3. 「これも修行」と思う
4. 待つ間に何かに感謝する

## 大きな忍耐のための準備
小さな忍耐を積むことで、大きな困難にも耐えられるようになる。
