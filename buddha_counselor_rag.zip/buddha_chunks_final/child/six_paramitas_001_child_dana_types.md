---
id: six_paramitas_001_child_types
type: child
parent_id: six_paramitas_001_dana_parent
scripture: 六波羅蜜
theme: ["三種の布施", "与えることの実践"]
situation: ["与えることを学びたい"]
token_estimate: 300
---
# 三種の布施

## 布施の種類
1. **財施**：物質的なものを与える
2. **法施**：教えや知識を与える
3. **無畏施**：安心と勇気を与える

## 最高の布施
執着なく与えること。与える者・受ける者・与える物への執着を離れた「三輪清浄」の布施が最高とされます。
