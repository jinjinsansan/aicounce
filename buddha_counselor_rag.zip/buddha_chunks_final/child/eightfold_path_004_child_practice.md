---
id: eightfold_path_004_child_practice
type: child
parent_id: eightfold_path_004_right_action_parent
scripture: 八正道
theme: ["正業の実践", "正しい行為"]
situation: ["行動を正したい"]
token_estimate: 280
---
# 正業の実践

## 避けるべき三つの行為
1. 殺生
2. 盗み
3. 邪淫

## 積極的な実践
- 生命を守る
- 与える
- 誠実な関係

## 日常での点検
「この行動は自分と他者を幸せにするか」と問う。
