---
id: mindfulness_001_child_breath
type: child
parent_id: mindfulness_001_sati_parent
scripture: 念処経
theme: ["呼吸への気づき", "入出息念"]
situation: ["呼吸瞑想を始めたい"]
token_estimate: 280
---
# 呼吸への気づき

## 入出息念（アーナパーナサティ）
1. 静かに座る
2. 自然な呼吸を観察
3. 吸う息に気づく
4. 吐く息に気づく
5. 思考が浮かんでも、呼吸に戻る

## 呼吸のアンカー
呼吸は常に今ここにある。心が迷った時の錨となる。
