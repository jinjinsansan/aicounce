---
id: dhammapada_008_child_small
type: child
parent_id: dhammapada_008_evil_parent
scripture: 法句経
theme: ["小さな悪", "習慣"]
situation: ["小さな悪行を正したい"]
token_estimate: 280
---
# 小さな悪を侮るな

## 法句経の教え
「小さな悪を侮るな。水滴も積もれば器を満たす」

## 小さな悪の例
- 小さな嘘
- ちょっとした悪口
- 少しの怠慢

## 習慣の力
小さな悪行も習慣になると大きな苦果を生む。逆に、小さな善行も積めば大きな功徳に。
